<?php
header("Content-Type: application/json; charset=UTF-8");

require('../model/Admin.php');
$obj_request = new Admin;

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'UPDATE':
        $json = file_get_contents('php://input');
        $json = json_decode($json);
        $id_car = $_GET['idCar'];
        $cant_product = $_GET['cantProduct'];

        $exit = $obj_request->update_car($id_car, $cant_product);
        if ($exit > 0) {
            echo json_encode(['status' => $exit]);
        } else {
            echo json_encode(['status' => 204, 'action' => 'update']); //204 NO SE ENCUENTRAN DATOS
        }
        break;
    case 'DELETE':
        $json = file_get_contents('php://input');
        $json = json_decode($json);
        $id_producto = $_GET['idProducto'];
        $exit = $obj_request->deleteCar($id_producto);
        if ($exit > 0) {
            echo json_encode(['status' => $exit]);
        } else {
            echo json_encode(['status' => 204]); //204 NO SE ENCUENTRAN DATOS
        }
        break;
    case 'GET':
        $exit = $obj_request->returnCar();

        if (count($exit) > 0) {
            echo json_encode($exit);
        } else {
            echo json_encode(['status' => 204]); //204 NO SE ENCUENTRAN DATOS
        }

        break;
    case 'POST':
        $json = file_get_contents('php://input');
        $json = json_decode($json);
        /* var_dump($json->idProducto); */
        $id_producto = $json->idProducto;
        $cant_product = $json->cantProduct;

        $exit = $obj_request->addToCar($id_producto, $cant_product);

        echo json_encode($exit);
        break;
    default:
        # code...
        break;
}
