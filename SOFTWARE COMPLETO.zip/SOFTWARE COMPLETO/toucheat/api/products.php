<?php
header("Content-Type: application/json; charset=UTF-8");

require('../model/Admin.php');
$obj_request = new Admin;

$method = $_SERVER['REQUEST_METHOD'];
switch ($method) {
    case 'POST':
        /* include('../model/Delete.php');
    $obj_delete = new Delete;
    $id_producto = $_GET['id_producto'];
    $exit = $obj_delete->deleteProduct($id_producto);
    echo json_encode(['response' => $exit]); */
        break;
    case 'GET':
        if ($_GET['categoria'] != '') {
           // session_start();
            $categoria = $_GET['categoria'];
            $sql = "SELECT * FROM productos INNER JOIN categorias ON categorias.idCategoria = productos.idCategoria WHERE idProveedor =". $_SESSION['supplierLog']['idUsuario'];
            if($_GET['categoria'] != 0) $sql .= " AND productos.idCategoria = $categoria";
            /* echo $sql . '<br>'; */
            $exit = $obj_request->exucute_sql($sql);
            if (count($exit) > 0) {
                echo json_encode($exit);
            } else {
                echo json_encode(['status' => 204]);
            }
        } else {
            echo json_encode(['response' => 'Se requiere el id de la categoria']);
        }
    break;
    case 'DELETE':
        if($_GET['idProducto'] != ''){
            $response = $obj_request->delete('productos','idProducto', $_GET['idProducto']);
            if($response){
                echo json_encode(['response' => 200]);    
            }else{
                echo json_encode(['response' => 'Error inesperado, vuelve a intentarlo']);    
            }
        }else{
            echo json_encode(['response' => 'se requiere el id del producto']);
        }
        break;
}
