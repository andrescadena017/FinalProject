<?php
header("Content-Type: application/json; charset=UTF-8");

require('../model/Admin.php');
$obj_request = new Admin;

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['idFactura'])) {
            $idFactura = $_GET['idFactura'];
            $sql = "SELECT * FROM factura INNER JOIN billdetails 
            ON billdetails.idFactura = factura.idFactura 
            INNER JOIN productos 
            ON productos.idProducto = billdetails.idProduct
            INNER JOIN usuarios
            ON usuarios.idUsuario = factura.idComprador WHERE factura.idFactura = '$idFactura' AND productos.idProveedor = " . $_SESSION['supplierLog']['idUsuario'];
        } else {
            # code...
            $sql = "SELECT DISTINCT  a.idFactura, d.userNombre, d.userCorreo, d.imgUrlUser, d.tel, a.fechaFac, a.envioDir, a.status, a.totalFac
            FROM factura as a
            INNER JOIN billdetails as b
            ON a.idFactura = b.idFactura
            INNER JOIN productos as c
            ON b.idProduct = c.idProducto
            INNER JOIN usuarios as d
            ON d.idUsuario = a.idComprador WHERE c.idProveedor =   " . $_SESSION['supplierLog']['idUsuario'];
        }
        $exit = $obj_request->exucute_sql($sql);

        if (count($exit) > 0) {
            echo json_encode(["data" => $exit, 'status' => 200]);
        } else {
            echo json_encode(['status' => 204]); //204 NO SE ENCUENTRAN DATOS
        }

        break;
    case 'UPDATE':
        $newStatus = $_GET['newStatus'];
        $idFactura = $_GET['idFactura'];
        $sql = "UPDATE factura SET status = '$newStatus' WHERE idFactura = '$idFactura';";
        $exit = $obj_request->guardar($sql);

        if ($exit) {
            echo json_encode(["data" => $exit, 'status' => 200]);
        } else {
            echo json_encode(['status' => 204]); //204 NO SE ENCUENTRAN DATOS
        }
        break;
    case 'POST':
        $json = file_get_contents('php://input');
        $json = json_decode($json);
        $today = date("F j, Y, g:i");
        /*bills*/
        $billId = strtotime($today);
        $totalFac = $json->total;
        $address = $json->envioDir;
        $billProducts = $json->carritto;

        $bill = $obj_request->newBill($billId, $address, $totalFac);

        if ($bill) {
            $obj_request->Addbilldetails($billId, $billProducts);
            echo json_encode(['response' => 'Factura generada correctamente', 'status' => 200]);
        } else {
            echo json_encode(['response' => 'no se registro la factura', 'status' => 400]);
        }
        break;
    default:
        # code...
        break;
}
