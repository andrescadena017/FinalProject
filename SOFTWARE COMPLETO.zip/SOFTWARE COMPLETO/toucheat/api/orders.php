<?php
header("Content-Type: application/json; charset=UTF-8");

require('../model/Admin.php');
$obj_request = new Admin;

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $sql = "SELECT * FROM factura INNER JOIN carrito ON factura.idCar = carrito.idCar WHERE factura.idUsuario = " . $_SESSION['supplierLog']['idUsuario'];
        $exit = $obj_request->exucute_sql($sql);

        if (count($exit) > 0) {
            echo json_encode($exit);
        } else {
            echo json_encode(['status' => 204]); //204 NO SE ENCUENTRAN DATOS
        }

        break;

    default:
        # code...
        break;


        
}
