<?php
header("Content-Type: application/json; charset=UTF-8");

require('../model/Admin.php');
$obj_request = new Admin;

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['idFactura'])) {
            $sql = "SELECT * FROM factura INNER JOIN billdetails 
            ON billdetails.idFactura = factura.idFactura 
            INNER JOIN productos 
            ON productos.idProducto = billdetails.idProduct
            INNER JOIN usuarios
            ON usuarios.idUsuario = productos.idProveedor
            WHERE factura.idFactura = " . $_GET['idFactura'];
        } else {
            $sql = "SELECT * FROM factura
            INNER JOIN usuarios
            ON factura.idComprador = usuarios.idUsuario 
            WHERE factura.idComprador = " . $_SESSION['buyer']['idUsuario'];
        }
        $exit = $obj_request->exucute_sql($sql);

        if (count($exit) > 0) {
            echo json_encode($exit);
        } else {
            echo json_encode(['status' => 204]); //204 NO SE ENCUENTRAN DATOS
        }

        break;

    default:
        # code...
        break;
}
