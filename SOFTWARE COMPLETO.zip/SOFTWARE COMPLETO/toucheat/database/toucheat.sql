-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.24 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table toucheat2.billdetails
CREATE TABLE IF NOT EXISTS `billdetails` (
  `idDetalles` int NOT NULL AUTO_INCREMENT,
  `idProduct` int DEFAULT NULL,
  `cantProduct` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `priceProduct` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `idFactura` int DEFAULT NULL,
  PRIMARY KEY (`idDetalles`),
  KEY `FK_Factura_idx` (`idFactura`),
  KEY `FK_Producto_idx` (`idProduct`),
  CONSTRAINT `FK_Factura` FOREIGN KEY (`idFactura`) REFERENCES `factura` (`idFactura`),
  CONSTRAINT `FK_Producto` FOREIGN KEY (`idProduct`) REFERENCES `productos` (`idProducto`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Dumping data for table toucheat2.billdetails: ~2 rows (approximately)
DELETE FROM `billdetails`;
/*!40000 ALTER TABLE `billdetails` DISABLE KEYS */;
INSERT INTO `billdetails` (`idDetalles`, `idProduct`, `cantProduct`, `priceProduct`, `idFactura`) VALUES
	(17, 35, '1', '6666', 1633511700),
	(18, 20, '1', '2300', 1633511700);
/*!40000 ALTER TABLE `billdetails` ENABLE KEYS */;

-- Dumping structure for table toucheat2.carrito
CREATE TABLE IF NOT EXISTS `carrito` (
  `idCar` int NOT NULL AUTO_INCREMENT,
  `idProducto` int NOT NULL,
  `cantProduct` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `idComprador` int NOT NULL,
  PRIMARY KEY (`idCar`),
  KEY `fk_car_producto_idx` (`idProducto`),
  KEY `fk_car_usr_idx` (`idComprador`),
  CONSTRAINT `fk_car_producto` FOREIGN KEY (`idProducto`) REFERENCES `productos` (`idProducto`)
) ENGINE=InnoDB AUTO_INCREMENT=149 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Dumping data for table toucheat2.carrito: ~0 rows (approximately)
DELETE FROM `carrito`;
/*!40000 ALTER TABLE `carrito` DISABLE KEYS */;
/*!40000 ALTER TABLE `carrito` ENABLE KEYS */;

-- Dumping structure for table toucheat2.categorias
CREATE TABLE IF NOT EXISTS `categorias` (
  `idCategoria` int NOT NULL AUTO_INCREMENT,
  `nameCategoria` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `imgCategoria` varchar(290) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idCategoria`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Dumping data for table toucheat2.categorias: ~10 rows (approximately)
DELETE FROM `categorias`;
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
INSERT INTO `categorias` (`idCategoria`, `nameCategoria`, `imgCategoria`) VALUES
	(1, 'Lacteos', '../files/categ/cat1Super.png'),
	(2, 'cereales', '../files/categ/cat1Super.png'),
	(3, 'Panaderia y Dulces', '../files/categ/panaderia-y-dulces4.jpg'),
	(4, 'Bebidas y Zumos', '../files/categ/zumos-y-bebidas4.jpg'),
	(5, 'Aceites y Harinas', '../files/categ/aceite-pasta-y-legumbres4.jpg'),
	(6, 'Aperitivos', '../files/categ/aperitivos4.jpg'),
	(7, 'Infantil', '../files/categ/infantil4.jpg'),
	(8, 'Cuidado Personal', '../files/categ/cosmetica-y-cuidado-personal4.jpg'),
	(9, 'Hogar y Limpieza', '../files/categ/hogar-y-limpieza4.jpg'),
	(10, 'Analgesicos y antinflamatorios', '');
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;

-- Dumping structure for table toucheat2.categoriasprov
CREATE TABLE IF NOT EXISTS `categoriasprov` (
  `idcategoriasProv` int NOT NULL AUTO_INCREMENT,
  `nombreCat` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `imgCat` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idcategoriasProv`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Dumping data for table toucheat2.categoriasprov: ~8 rows (approximately)
DELETE FROM `categoriasprov`;
/*!40000 ALTER TABLE `categoriasprov` DISABLE KEYS */;
INSERT INTO `categoriasprov` (`idcategoriasProv`, `nombreCat`, `imgCat`) VALUES
	(1, 'Supermercados', '../files/categ/cat1Super.png'),
	(2, 'Restaurantes', NULL),
	(3, 'Heladerias y comidas rapidas', NULL),
	(4, 'Fruvers', NULL),
	(5, 'Droguerias', NULL),
	(6, 'Veterinarias', NULL),
	(7, 'Belleza y estética', NULL),
	(8, 'Ferreterías', NULL);
/*!40000 ALTER TABLE `categoriasprov` ENABLE KEYS */;

-- Dumping structure for table toucheat2.departamentos
CREATE TABLE IF NOT EXISTS `departamentos` (
  `idDto` int NOT NULL AUTO_INCREMENT,
  `nameDto` varchar(65) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`idDto`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Dumping data for table toucheat2.departamentos: ~0 rows (approximately)
DELETE FROM `departamentos`;
/*!40000 ALTER TABLE `departamentos` DISABLE KEYS */;
INSERT INTO `departamentos` (`idDto`, `nameDto`) VALUES
	(1, 'Cundinamarca');
/*!40000 ALTER TABLE `departamentos` ENABLE KEYS */;

-- Dumping structure for table toucheat2.factura
CREATE TABLE IF NOT EXISTS `factura` (
  `idFactura` int NOT NULL AUTO_INCREMENT,
  `idComprador` int DEFAULT NULL,
  `fechaFac` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `envioDir` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `totalFac` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `descuento` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `idVendedor` int DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`idFactura`),
  KEY `FK_comprador_idx` (`idComprador`),
  KEY `fk_vendedor_idx` (`idVendedor`),
  CONSTRAINT `FK_comprador` FOREIGN KEY (`idComprador`) REFERENCES `usuarios` (`idUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=1633511701 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Dumping data for table toucheat2.factura: ~1 rows (approximately)
DELETE FROM `factura`;
/*!40000 ALTER TABLE `factura` DISABLE KEYS */;
INSERT INTO `factura` (`idFactura`, `idComprador`, `fechaFac`, `envioDir`, `totalFac`, `descuento`, `idVendedor`, `status`) VALUES
	(1633511700, 26, '2021-10-06 16:15:44', 'Carrera 20 #10-37', '8966', '0', NULL, 0);
/*!40000 ALTER TABLE `factura` ENABLE KEYS */;

-- Dumping structure for table toucheat2.municipios
CREATE TABLE IF NOT EXISTS `municipios` (
  `idMunicipio` int NOT NULL AUTO_INCREMENT,
  `municipio` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `idDepartamento` int NOT NULL,
  PRIMARY KEY (`idMunicipio`),
  KEY `fk_municipios_departamentos` (`idDepartamento`),
  CONSTRAINT `fk_municipios_departamentos` FOREIGN KEY (`idDepartamento`) REFERENCES `departamentos` (`idDto`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_spanish_ci;

-- Dumping data for table toucheat2.municipios: ~2 rows (approximately)
DELETE FROM `municipios`;
/*!40000 ALTER TABLE `municipios` DISABLE KEYS */;
INSERT INTO `municipios` (`idMunicipio`, `municipio`, `idDepartamento`) VALUES
	(1, 'Tocaima', 1),
	(2, 'Agua de Dios', 1);
/*!40000 ALTER TABLE `municipios` ENABLE KEYS */;

-- Dumping structure for table toucheat2.productos
CREATE TABLE IF NOT EXISTS `productos` (
  `idProducto` int NOT NULL AUTO_INCREMENT,
  `nameProduct` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `marcaProduct` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `cantProducto` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `volumProducto` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `priceProduct` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `idCategoria` int NOT NULL,
  `idProveedor` int NOT NULL,
  `imgUrlProduct` varchar(256) CHARACTER SET armscii8 COLLATE armscii8_bin DEFAULT NULL,
  PRIMARY KEY (`idProducto`),
  KEY `fk_producto_proveedor_idx` (`idProveedor`),
  KEY `fk_producto_proveedor` (`idProveedor`),
  CONSTRAINT `fk_producto_proveedor` FOREIGN KEY (`idProveedor`) REFERENCES `usuarios` (`idUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Dumping data for table toucheat2.productos: ~21 rows (approximately)
DELETE FROM `productos`;
/*!40000 ALTER TABLE `productos` DISABLE KEYS */;
INSERT INTO `productos` (`idProducto`, `nameProduct`, `marcaProduct`, `cantProducto`, `volumProducto`, `priceProduct`, `idCategoria`, `idProveedor`, `imgUrlProduct`) VALUES
	(17, 'Leche en polvo', 'Klim', '5', '480g', '8500', 1, 34, '../files/7702001041404.jpg'),
	(20, 'Avena', 'Quaker', '8', '500g', '2300', 2, 34, ''),
	(21, 'Pan Blanco', 'Bimbo', '12', '720g', '6200', 3, 34, ''),
	(24, 'Coca Cola ', 'Coca Cola', '15', '600ml', '1500', 4, 34, '../files/Gaseosa-Coca-Cola-Pet-600-ml-370169_a.jpg'),
	(25, 'Antitranspirante', 'Rexona', '6', '130g', '2000', 8, 34, ''),
	(26, 'empanadas precoc', 'industria nacional', '10', '600g', '5300', 6, 34, '../files/4018980.jpg'),
	(27, 'Jabon Rey', 'rey', '20', '160g', '3000', 9, 33, ''),
	(28, 'Compota ', 'industria nacional', '14', '50g', '3000', 7, 34, ''),
	(29, 'Jabon liquido', 'FAB', '13', '900g', '4600', 9, 34, ''),
	(30, 'Limpia pisos', 'Pisolimpio', '6', '400ml', '2000', 9, 34, '../files/img_headerTARJETAS@2x.png'),
	(31, 'Harina de Trigo', 'Harinas del Valle', '15', '1lb', '1100', 5, 34, '../files/banerLacteos.PNG'),
	(34, 'Coca Cola', 'Coca Cola', '5', '1.5L', '4000', 4, 34, '../files/png-transparent-coca-cola-fizzy-drinks-cocacola-diet-coke-cocacola-zero-sugar-cocacola-life-coca-cola-drink-supermarket.png'),
	(35, 'arroz blanco', 'industria nacional', '10', '480g', '6666', 2, 34, '../files/arroz.PNG'),
	(36, 'pasta doria', 'doria', '8', '480g', '5000', 5, 34, '../files/240_F_287316290_lh96pUiBvbhXCSYTgxkNwoof9GhMzfRb.jpg'),
	(38, 'pasta doria', 'doria', '4', '480g', '5000', 5, 34, '../files/240_F_287316290_lh96pUiBvbhXCSYTgxkNwoof9GhMzfRb.jpg'),
	(40, 'Acetaminofen', 'MK', '10', '10u', '2500', 10, 43, '../files/descarga.jpg'),
	(41, 'Acetaminofen', 'mk', '4', '150g', '600', 10, 43, '../files/descarga.jpg'),
	(43, 'PRUEBA', 'ASDA', '143', '3214', '3425', 5, 34, '../files/HBO_Max_logo.png'),
	(44, 'NETWE', 'FSDFG', '345', '4235', '3425', 5, 34, '../files/580b57fcd9996e24bc43c529.png'),
	(45, 'ADRTQ', 'ASDF', '354', '534', '435', 5, 34, '../files/descarga.png'),
	(46, '3Q4QERT', 'QTQER', '435', '432', '345', 5, 34, '../files/descarga.png');
/*!40000 ALTER TABLE `productos` ENABLE KEYS */;

-- Dumping structure for view toucheat2.prueba
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `prueba` (
	`idUsuario` INT(10) NOT NULL,
	`userNombre` VARCHAR(255) NOT NULL COLLATE 'utf8mb4_spanish_ci',
	`imgUrlProv` VARCHAR(250) NULL COLLATE 'utf8mb4_spanish_ci',
	`categoriaPro` INT(10) NULL,
	`nombreCat` VARCHAR(45) NULL COLLATE 'utf8mb4_spanish_ci',
	`categoryName` VARCHAR(45) NULL COLLATE 'utf8mb4_spanish_ci'
) ENGINE=MyISAM;

-- Dumping structure for table toucheat2.roles
CREATE TABLE IF NOT EXISTS `roles` (
  `idRol` int NOT NULL AUTO_INCREMENT,
  `tipoRol` varchar(9) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`idRol`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_spanish_ci;

-- Dumping data for table toucheat2.roles: ~2 rows (approximately)
DELETE FROM `roles`;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`idRol`, `tipoRol`) VALUES
	(1, 'Usuario'),
	(2, 'proveedor');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;

-- Dumping structure for table toucheat2.usuarios
CREATE TABLE IF NOT EXISTS `usuarios` (
  `idUsuario` int NOT NULL AUTO_INCREMENT,
  `userNombre` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `userApellido` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `userCorreo` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `userPass` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `fechaNaUser` datetime DEFAULT NULL,
  `dirUser` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `idMunicipio` int NOT NULL,
  `idRol` int NOT NULL,
  `tel` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `prNit` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `prRut` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `timeEnd` time DEFAULT NULL,
  `timeStart` time DEFAULT NULL,
  `imgUrlUser` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `imgUrlProv` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `categoriaPro` int DEFAULT NULL,
  PRIMARY KEY (`idUsuario`),
  UNIQUE KEY `userCorreo_UNIQUE` (`userCorreo`),
  KEY `fk_usuarios_roles` (`idRol`),
  KEY `fk_provedor_cat_idx` (`categoriaPro`),
  KEY `fk_usuario_munc_idx` (`idMunicipio`),
  CONSTRAINT `fk_provedor_cat` FOREIGN KEY (`categoriaPro`) REFERENCES `categoriasprov` (`idcategoriasProv`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_usuario_munc` FOREIGN KEY (`idMunicipio`) REFERENCES `municipios` (`idMunicipio`),
  CONSTRAINT `fk_usuarios_roles` FOREIGN KEY (`idRol`) REFERENCES `roles` (`idRol`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Dumping data for table toucheat2.usuarios: ~17 rows (approximately)
DELETE FROM `usuarios`;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` (`idUsuario`, `userNombre`, `userApellido`, `userCorreo`, `userPass`, `fechaNaUser`, `dirUser`, `idMunicipio`, `idRol`, `tel`, `prNit`, `prRut`, `timeEnd`, `timeStart`, `imgUrlUser`, `imgUrlProv`, `categoriaPro`) VALUES
	(26, 'Andres', 'Munayar', 'admin@admin.com', '$2y$10$pfddhn80jK17z5sV2loPc.L4ejvQ/VdMSe1I8WRqIgAAHQaVdGEjy', '2021-05-17 00:00:00', 'DG 6 # 14 - 260', 1, 1, '3123833733', NULL, NULL, NULL, NULL, '../files/Diamantes-Free-Fire-Brasil.jpg', '../files/Diamantes-Free-Fire-Brasil.jpg', NULL),
	(28, 'EDGAR', 'MUNAYAR', 'basallo17@MAIL.COM', '$2y$10$FNuINvNNN/xQDt0F3b/9t.0EyxmeZUBQ/Y10hRjSlYp1.ycRO5bRa', '2021-05-21 00:00:00', 'aquí', 2, 1, '8340000000', NULL, NULL, NULL, NULL, '../files/Diamantes-Free-Fire-Brasil.jpg', NULL, NULL),
	(33, 'Supermercado 1', NULL, 'Supermercado1@yahoo.es', '$2y$10$xQxaZjHojLfcx5o6ap7xqutvU8Ik768Wfx9DFtw43Cwkq9/dXbiWS', NULL, 'Calle 4 # 5-24', 1, 2, '8254596', '7894523', '546546', '18:45:00', '07:00:00', NULL, '../files/logoSuper.PNG', 1),
	(34, 'Supermercado2', NULL, 'Supermercado2@email.com', '$2y$10$ArDtL55wSw8GK2WbSV/FR.78YoAgyHaJ4h0Iityxw8CyWOhUO1APG', NULL, 'Diagonal 5 calle 2', 1, 2, '12345677', '44855', '44321555', '12:59:00', '00:01:00', NULL, '../files/logoSuper3.PNG', 1),
	(35, 'Restaurante 1', NULL, 'Restaurante1@correo.com', '$2y$10$lN/l1nK.Anjh88sGyvclwuC7lAtp51SUerfBe68hYZKYpiGSQ2nxC', NULL, 'carrera 4', 1, 2, '8524569', '1258965', '5141651', '18:09:00', '06:09:00', NULL, '../files/res1.PNG', 2),
	(36, 'Restaurante 2', NULL, 'Restaurante2@correo.com', '$2y$10$xuVpxg2Bbxi85mTvQk3.WOgZXCYYw1YhY80b9bUB4T8g.o0hZIBFG', NULL, 'calle 24', 1, 2, '7894561235', '12345688', '3', '18:10:00', '06:09:00', NULL, '../files/res2.PNG', 2),
	(37, 'Heladeria one', NULL, 'Heladeriaone@gmail.com', '$2y$10$O8Ie5mtvH1V8Qg0aB6ahg.P8/20YxdHbYFdOdWBuUi/0tD1TiB.nW', NULL, 'Tranversal 3, carrera 8 # 5-96', 1, 2, '8340000', '9876543', '852369', '18:11:00', '08:11:00', NULL, '../files/hela1.PNG', 3),
	(38, 'Fruver central', NULL, 'fruver@fruver.co', '$2y$10$P80eDhjPlQ2Gp83N/iq6r.TX2nhqz/w0eWBFlZcl3.SqILxcbFFIy', NULL, 'Calle 1 - 1-17', 1, 2, '7458961', '8956', '789', '21:15:00', '10:13:00', NULL, '../files/fruver1.png', 4),
	(39, 'Supermercado ', NULL, 'supermercadotres@gmail.com', '$2y$10$c7VZcIgGQfQKtQnU8Y2t3.IsP2qIibGKrVPnel5wgRQSmmI8S0jHi', NULL, 'carrera 0', 1, 2, '7458961', '123', '1234', '19:00:00', '07:59:00', NULL, '../files/logoSuper3.PNG', 1),
	(40, 'Supermercado 4', NULL, 'Supermercado4@mail.co', '$2y$10$rFQEL9AQYN1rCUjPvjen2O/CgdYz/O5gakVB/Vf2VJVZgHCiq8Nga', NULL, 'carrera 4', 1, 2, '8524569', '5698', '7413', '06:54:00', '06:53:00', NULL, '../files/res4.PNG', 1),
	(41, 'Restaurante 3', NULL, 'Supermercado5@tm.com', '$2y$10$1huw1U2NrQgKGMmYZ6qj0e7IQo2hYwSC76KXtZxb/lGGEB7WDLu8.', NULL, 'aquí', 1, 2, '3123833733', '1234567', '5896', '06:56:00', '18:55:00', NULL, '../files/res5.PNG', 2),
	(42, 'fruver2', NULL, 'fruver2@fruver.co', '$2y$10$gwqVolOBAIgHMb1rtCkqyuCcSKeZ9hCDdhggjE1miKCNnSyOiE2RW', NULL, 'Calle 1 - 1-17', 1, 2, '7458961', '12345688', '789', '21:49:00', '16:49:00', NULL, '../files/fruver2.jpg', 4),
	(43, 'Droguerias2', NULL, 'Droguerias2@EMAIL.COM', '$2y$10$Bn6rE5npQ9ZLMN06eYazW.ktwxJQC2Grkyc.dDEHtlhOgDIyMQmIW', NULL, 'Calle 1 - 1-17', 1, 2, '7458961', '12345688', '789', '20:52:00', '06:55:00', NULL, '../files/drog1.png', 5),
	(44, 'Restaurante5', NULL, 'Restaurante5@email.com', '$2y$10$HAFFPhSzDR56/8mdFAT3iOaIBEte/Ed7LMj8HbDrJePhgJG5EzRJy', NULL, 'Diagonal 6 14-260', 1, 2, '8340000', '1111', '111111', '06:05:00', '18:05:00', NULL, '../files/res5.PNG', 2),
	(45, 'EDGAR', 'MUNAYAR', 'VI@GMAIL.COM.CO', '$2y$10$VdVVk8../hPBb2Pk9uskg.WXNxDGVi515AFc0gZg8UtXFdD/74i5S', '2021-05-08 00:00:00', 'aquí', 1, 1, '8340000', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(46, 'Ferreteria 1', NULL, 'Ferreteria@email.com', '$2y$10$rNe2v1cAcwDl5qvqMIoKfePfHNH4nUa/o..LDU0sMjvHCwhZHTncW', NULL, 'aquí', 1, 2, '7458961', '258963', '874125', '17:16:00', '07:16:00', NULL, '../files/fer1.png', 8),
	(47, 'asdfgeq', 'zxcvb', 'mail@correo.com', '$2y$10$CDGQ4GYPzcWRcdMjHkmgB.GI1HQyYvkrkhx1C23e1URNXNa7RhLy2', '2021-06-09 00:00:00', 'Tranversal 3, carrera 8 # 5-96', 2, 1, '8340000', NULL, NULL, NULL, NULL, ' ', NULL, NULL);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;

-- Dumping structure for view toucheat2.prueba
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `prueba`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `prueba` AS select `usuarios`.`idUsuario` AS `idUsuario`,`usuarios`.`userNombre` AS `userNombre`,`usuarios`.`imgUrlProv` AS `imgUrlProv`,`usuarios`.`categoriaPro` AS `categoriaPro`,`categoriasprov`.`nombreCat` AS `nombreCat`,`categoriasprov`.`nombreCat` AS `categoryName` from (`usuarios` join `categoriasprov` on((`usuarios`.`categoriaPro` = `categoriasprov`.`idcategoriasProv`))) where (`usuarios`.`idRol` = '2') order by `categoriasprov`.`nombreCat`;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
