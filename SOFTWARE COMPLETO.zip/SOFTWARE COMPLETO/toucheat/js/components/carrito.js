Vue.component('carrito-component', {
    data: function () {
        return {
            modal: false,
            address: '',
            addressRequired: false,
            notify: false
        }
    },
    methods: {
        restar(cantProduct, index) {
            this.car[index].cantProduct = cantProduct - 1;
            this.changeCanProducts(this.car[index])
        },
        sumar(cantProduct, index) {
            this.car[index].cantProduct = (cantProduct * 1) + 1;
            this.changeCanProducts(this.car[index])

        },
        remove(idProduct) {
            let url = "../api/car.php?idProducto=" + idProduct;
            fetch(url, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                }
            })
                .then((response) => response.json())
                .then((result) => {
                    this.$emit('reload');
                })
                .catch((error) => {
                    console.log(error);
                })
        },
        changeCanProducts(data) {
            let url = `../api/car.php?idCar=  ${data.idCar}&cantProduct=${data.cantProduct}`;
            fetch(url, {
                method: 'UPDATE',
                headers: {
                    'Content-Type': 'application/json'
                }
            })
                .then((response) => response.json())
                .then((result) => {
                    this.$emit('reload');
                })
                .catch((error) => {
                    console.log(error);
                })
        },
        orderNow() {
            if (this.address != '') {
                this.addressRequired = false
                let total = 0
                this.car.map(e => {
                    total = (total * 1) + (e.priceProduct * e.cantProduct)
                })
                let data = {
                    envioDir: this.address,
                    total: total,
                    carritto: this.car
                }
                fetch(`../api/bill.php`, {
                    method: 'POST',
                    body: JSON.stringify(data)
                })
                    .then((response) => response.json())
                    .then((result) => {
                        this.$emit('reload');
                        this.notify = true
                    })
                    .catch((error) => {
                        console.log(error);
                    })
            } else {
                this.addressRequired = true
            }
        },

    },
    computed: {
        carTotal() {
            let total = 0
            this.car.map(e => {
                total = (total * 1) + (e.priceProduct * e.cantProduct)
            })
            return total;
        }
    },
    created() {
        // this.carTotal()
        //console.log(this.car);
    },
    props: {
        car: {
            required: true
        }
    },
    template:
        `
        <div class="container mx-auto px-4 sm:px-8">
    <div class="py-8">

        <div class="-mx-4 sm:-mx-8 px-4 sm:px-8 py-4 overflow-x-auto">
            <div class="inline-block min-w-full shadow rounded-lg overflow-hidden">
                <table class="min-w-full leading-normal">
                    <thead>
                        <tr>
                            <th class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                Producto
                            </th>
                            <th class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                Cantidad
                            </th>
                            <th class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                Vendedor
                            </th>
                            <th class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                Precio Por unidad
                            </th>

                            <th class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                Precio total
                            </th>

                            <th class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                Acciones
                            </th>
                        </tr>
                    </thead>
                    <tbody>                        
                            <tr v-for="(car, index) in car">
                                <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                                    <div class="flex items-center">
                                        <div class="flex-shrink-0 w-10 h-10">
                                            <img class="w-full h-full rounded-full" :src="car.imgUrlProduct" alt="" />
                                        </div>
                                        <div class="ml-3">
                                            <p class="text-gray-900 whitespace-no-wrap">
                                                {{car.nameProduct}}
                                            </p>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm w-2/12">
                                    <div class="bg-gray-100 flex items-center justify-center rounded-md">
                                        <span @click="restar(car.cantProduct, index)" class="text-xl	w-2/12 flex items-center justify-center cursor-pointer hover:text-gray-800" >-</span>
                                        <input @change="changeCanProducts(car)" class="bg-gray-200 w-8/12 py-1 text-center  text-gray-700 bg-white   rounded-md dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600 focus:border-blue-500 dark:focus:border-blue-500 focus:outline-none focus:ring" type="number" v-model="car.cantProduct" min="1">
                                        <span @click="sumar(car.cantProduct, index)" class="text-xl	w-2/12 flex items-center justify-center cursor-pointer hover:text-gray-800 " >+</span>
                                    </div>
                                    <!-- <p class="text-gray-900 whitespace-no-wrap"> 
                                    </p> -->
                                </td>
                                <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                                    <p class="text-gray-900 whitespace-no-wrap">
                                    {{car.userNombre}}
                                    </p>
                                </td>
                                <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                                    <span class="relative inline-block px-3 py-1 font-semibold text-green-900 leading-tight">
                                        <span aria-hidden class="absolute inset-0 bg-green-200 opacity-50 rounded-full"></span>
                                        <span class="relative">$ {{car.priceProduct}}</span>
                                    </span>
                                </td>

                                <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                                    <span class="relative inline-block px-3 py-1 font-semibold text-green-900 leading-tight">
                                        <span aria-hidden class="absolute inset-0 bg-green-200 opacity-50 rounded-full"></span>
                                        <span class="relative">$ {{car.priceProduct * car.cantProduct}}</span>
                                    </span>
                                </td>

                                <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                                    
                                        <span class="relative inline-block px-3 py-1 font-semibold text-red-900 leading-tight">
                                            <span aria-hidden class="absolute inset-0 bg-red-200 opacity-50 rounded-full"></span>
                                            <span class="relative cursor-pointer" @click="remove(car.idCar)">X</span>
                                        </span>
                                    
                                </td>
                            </tr>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
    <div class="flex justify-end" v-if="Object.keys(car).length">
        <span @click="modal = true" class="rounded-sm  w-4/12 p-1 bg-yellow-500 hover:bg-yellow-600 text-white text-center font-bold cursor-pointer" >Finalizar Compra</span>
    </div>
    <div v-else>
        <p class="text-gray-500 text-center">No hay productos en el carrito</p>
    </div>
    

    <div v-if="modal" class="flex justify-center h-screen items-center bg-gray-200 antialiased absolute inset-0 bg-opacity-50">
        <div class="flex flex-col w-11/12 sm:w-5/6 lg:w-1/2 max-w-2xl mx-auto rounded-lg border border-gray-300 shadow-xl">
            <div class="flex flex-row justify-between p-6 bg-white border-b border-gray-200 rounded-tl-lg rounded-tr-lg">
                <p class="font-semibold text-gray-800">Detalles de envío</p> <svg @click="modal=false" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 cursor-pointer">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </div>
            <div v-if="!notify">
            <div class="flex flex-col px-6 py-5 bg-gray-50">
                <p class="mb-2 font-semibold text-gray-700">Dirección*</p> 
                <input  v-model="address" type="text" name="" placeholder="Dirección donde se enviaran tus productos" id="" class="p-2 mb-5 bg-white border border-gray-200 rounded shadow-sm "></input>
                <p v-if="addressRequired" class="text-red-600 text-xs">Por favor ingresa la dirección</p>
                <hr>
                <p>Total: $ {{carTotal}}</p>
            </div>
            <div  class="flex flex-row items-center justify-between p-5 bg-white border-t border-gray-200 rounded-bl-lg rounded-br-lg">
                <p class="font-semibold text-gray-600 cursor-pointer" @click="modal=false">Cancel</p> 
                <button @click="orderNow" class="px-4 py-2 text-white font-semibold bg-blue-500 rounded">
                    Save
                </button>
            </div>
            </div>
            <div v-else>
            <div class="flex flex-col px-6 py-5 bg-gray-50">
                <p class="mb-2 font-semibold text-gray-700">Tu orden fue aceptada</p> 

            </div>
            <div  class="flex flex-row items-center justify-between p-5 bg-white border-t border-gray-200 rounded-bl-lg rounded-br-lg">
                <p class="font-semibold text-gray-600 cursor-pointer" @click="modal=false">cerrar</p> 
            </div>
            </div>
        </div>
    </div>
    
</div>
    `
})