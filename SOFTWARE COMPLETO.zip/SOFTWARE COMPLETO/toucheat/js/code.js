Vue.component('products-view', {
  data() {
    return {
      products: [],
      cantProduct: 1
    }
  },
  methods: {
    getProducts() {
      let url_string = window.location.href;
      let url = new URL(url_string);
      let shopId = url.searchParams.get("shopId");
      let categoryId = url.searchParams.get("categoryId");
      fetch(`../api/shopProducts.php?shopId=${shopId}&categoryId=${categoryId}`)
        .then((response) => response.json())
        .then((result) => {
          this.products = result.products
        })
        .catch((error) => {
          console.log('Huvo un error ');
        })
    },
    addToCar(product) {
      let url = "../api/car.php";
      let data = {
        'idProducto': product.idProducto,
        'cantProduct': this.cantProduct,
      }
      fetch(url, {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
          'Content-Type': 'application/json'
        }
      })
        .then((response) => response.json())
        .then((result) => {

          this.$emit('load-card')
          //  this.$refs.modal.$emit('loadCard');

        })
        .catch((error) => {
          this.$emit('load-card')
        })
    }
  },
  created() {
    this.getProducts();
  },
  template: `
  <div>
    <div class="flex justify-center items-center flex-wrap">
      <div  v-for="product in products"  class="container mx-auto max-w-sm w-full p-4 sm:w-1/2" >
        <div class="card flex flex-col justify-center p-10 bg-white rounded-lg shadow-2xl">
          <div class="prod-title">
            <p class="text-2xl uppercase text-gray-900 font-bold">{{product.nameProduct}}</p>
            <p class="uppercase text-sm text-gray-400">
            {{product.marcaProduct}}
            </p>
            <p class="uppercase text-sm text-gray-400">
            {{product.volumProducto}}
            </p>
          </div>
          <div class="prod-img">
            <img :src="product.imgUrlProduct"
                class="w-full object-cover object-center" />
          </div>
          <div class="prod-info grid gap-10">
            <div class="flex flex-col md:flex-row justify-between items-center text-gray-900">
              <p class="font-bold text-xl">{{product.priceProduct}}</p>
              <button @click="addToCar(product)"
                      class="px-6 py-2 transition ease-in duration-200 uppercase rounded-full hover:bg-gray-800 hover:text-white border-2 border-gray-900 focus:outline-none">Add
                to cart</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  `,
})

Vue.component('orders', {
  data() {
    return {
      orders: [],
      showModal: false,
      bill: [],
      billDetails: [],
      filter: '',
      filterActive: 3 // aqui puedo cambiar cual es el filtro activo 
    }
  },
  methods: {
    /**
     * Esta funcion se encarga de traer todas las facturas
     */
    getOrders() {
      setInterval(() => {
        fetch("../api/bill.php")
          .then((response) => response.json())
          .then((result) => {
            if (result.status == 200) {
              this.orders = result.data;
            }
          })
          .catch((error) => {
            console.log(error);
          })
      }, 1000);
    },
    /**
     * esta funcion se encarga de cambiar el estado de la factura en la base de datos 
     * @param {*} newStatus 
     * @param {*} idFactura 
     */
    changeStatus(newStatus, idFactura) {
      fetch(`../api/bill.php?newStatus=${newStatus}&idFactura=${idFactura}`, {
        method: 'UPDATE'
      })
        .then((response) => response.json())
        .then((result) => {
          console.log(result);
        })
        .catch((error) => {
          console.log(error);
        })
    },
    details(bill) {
      this.bill = bill;
      console.log(this.bill);
      fetch(`../api/bill.php?idFactura=${bill.idFactura}`)
        .then((response) => response.json())
        .then((result) => {
          console.log(result);
          if (result.status == 200) {
            this.showModal = true;
            this.billDetails = result.data;
            console.log(this.billDetails);
          }
        })
        .catch((error) => {
          console.log(error);
        })
    }
  },
  computed: {
    filterOrders() {
      if (this.filterActive == 1) {
        return this.orders
          .filter((item) => {
            return item.status.toLowerCase().includes('1')
          }
          )
          .filter((item) => {

            return item.userNombre.toLowerCase().includes(this.filter.toLowerCase())
          }
          )
      } else if (this.filterActive == 2) {
        return this.orders
          .filter((item) => {
            return item.status.toLowerCase().includes('0')
          }
          )
          .filter((item) => {

            return item.userNombre.toLowerCase().includes(this.filter.toLowerCase())
          }
          )
      }
      return this.orders
        .filter((item) => {

          return item.userNombre.toLowerCase().includes(this.filter.toLowerCase())
        }
        )
    }
  },
  created() {
    this.getOrders()
  },
  template: `
  <div>
  <div>
  <div class="my-2 flex sm:flex-row flex-col">
                <div class="flex flex-row mb-1 sm:mb-0">                    
                    <div class="relative">
                        <select v-model="filterActive"
                            class="appearance-none h-full rounded-r border-t sm:rounded-r-none sm:border-r-0 border-r border-b block appearance-none w-full bg-white border-gray-400 text-gray-700 py-2 px-4 pr-8 leading-tight focus:outline-none focus:border-l focus:border-r focus:bg-white focus:border-gray-500">                            
                            <option value="1">Entregados</option>
                            <option value="2">Pendientes</option>
                            <option value="3">Todos</option>
                        </select>
                        <div
                            class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                            <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                            </svg>
                        </div>
                    </div>
                </div>
                <div class="block relative">
                    <span class="h-full absolute inset-y-0 left-0 flex items-center pl-2">
                        <svg viewBox="0 0 24 24" class="h-4 w-4 fill-current text-gray-500">
                            <path
                                d="M10 4a6 6 0 100 12 6 6 0 000-12zm-8 6a8 8 0 1114.32 4.906l5.387 5.387a1 1 0 01-1.414 1.414l-5.387-5.387A8 8 0 012 10z">
                            </path>
                        </svg>
                    </span>
                    <input placeholder="Search" v-model="filter"
                        class="appearance-none rounded-r rounded-l sm:rounded-l-none border border-gray-400 border-b block pl-8 pr-6 py-2 w-full bg-white text-sm placeholder-gray-400 text-gray-700 focus:bg-white focus:placeholder-gray-600 focus:text-gray-700 focus:outline-none" />
                </div>
            </div>
  </div>
  <table class="min-w-full">
  <thead>
      <tr>
          <th class="text-center px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">
              Cliente</th>
          <th class="text-center px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">
              Factura</th>
              <th class="text-center px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">
              Fecha</th>
              
          <th class="text-center px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">
              valor</th>
              <th class="text-center px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">
              Estado</th>
              <th class="text-center px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">
              Detalles </th>
              <th class="text-center px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">
              Cambiar estado</th>
      </tr>
  </thead>

  <tbody class="bg-white" v-for="order in filterOrders">
      <tr>
          <td class="px-6 py-4 whitespace-no-wrap border-b border-gray-200">
              <div class="flex items-center">
                  <div class="flex-shrink-0 h-10 w-10">
                      <img class="h-10 w-10 rounded-full" :src="order.imgUrlUser" alt="">
                  </div> 

                  <div class="ml-4">
                      <div class="text-sm leading-5 font-medium text-gray-900">{{order.userNombre}}
                      </div>
                      <div class="text-sm leading-5 text-gray-500">{{order.tel}}</div>
                  </div>
              </div>
          </td>

          <td class="text-center px-6 py-4 whitespace-no-wrap border-b border-gray-200">
              
              <div class="text-sm leading-5 text-gray-500">{{order.idFactura}}</div>
          </td>

          <td class="px-6 py-4 whitespace-no-wrap border-b border-gray-200">
              <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">{{order.fechaFac}}</span>
          </td>
          <td class="px-6 py-4 whitespace-no-wrap border-b border-gray-200">
          <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">$ {{order.totalFac}}</span>
          </td>
          <td class="px-6 py-4 whitespace-no-wrap border-b border-gray-200 text-sm leading-5 text-gray-500">
          <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800" v-if="order.status == 1">Entregado</span>
          <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800" v-else>Pendiente</span>
          </td>
          <td class="px-6 py-4 whitespace-no-wrap border-b border-gray-200 text-center">
            <svg @click="details(order)" xmlns="http://www.w3.org/2000/svg" class="cursor-pointer h-5 w-5 m-auto text-sm leading-5 text-gray-500 hover:text-gray-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
          </td>
          <td class="px-6 py-4 whitespace-no-wrap text-right border-b border-gray-200 text-sm leading-5 font-medium">
              <div @click="changeStatus(0, order.idFactura)" class="cursor-pointer text-indigo-600 hover:text-indigo-900" v-if="order.status == 1">Pendiente</div>
              <div @click="changeStatus(1, order.idFactura)" class="cursor-pointer text-indigo-600 hover:text-indigo-900" v-else>Entregado</div>
          </td>

      </tr>

  </tbody>
</table>
<div class="bg-gray-50 bg-opacity-80 min-h-screen flex items-center justify-center p-1 md:px-16 fixed top-0 left-0 w-full " v-if="showModal">  
  <div class="relative w-full md:w-9/12">
  <div class="flex justify-end text-gray-700 cursor-pointer">
  <svg @click="showModal = false" xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
  </svg>
  </div>
    <div class="absolute top-0 -left-4 w-72 h-72 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob "></div>
    <div class="absolute top-0 -right-4 w-72 h-72 bg-green-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000"></div>
    <div class="absolute -bottom-32 left-20 w-72 h-72 bg-yellow-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-4000"></div>
    <div class="absolute -bottom-32 right-20 w-72 h-72 bg-yellow-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-4000"></div>

    <div class="md:m-8 relative ">
      <div class="p-5 bg-white ">
        <div class="py-1 flex justify-between items-center">
          <div class="w-6/12 h-4 rounded">{{bill.userNombre}}</div>
          <div class="w-6/12 rounded-lg text-right">{{bill.fechaFac}}</div>
        </div>

        
        <div class="py-1 flex justify-between items-center">
          <div class="w-6/12 h-4 rounded">{{bill.tel}}</div>
          <div class="w-6/12 h-6 rounded-lg  text-right">{{bill.userCorreo}}</div>
        </div>
        <div class="py-1 flex justify-between items-center">
        <div class="w-6/12 h-4 rounded">{{bill.envioDir}}</div>
          <div class="w-24 h-6 rounded-lg bg-purple-300 text-center" >$ {{bill.totalFac}}</div>
        </div>       
      </div>
      <div class="w-full overflow-x-auto">
      <table class="min-w-full">
      <thead>
          <tr>
              <th class="text-center px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">
              Nombre</th>
              <th class="text-center px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">
              Marca</th>
                  <th class="text-center px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">
              Unidad de medida</th>                  
              <th class="text-center px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">
              Valor Unidad</th>
              <th class="text-center px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">
              cantidad</th>
              <th class="text-center px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">
              Valor total</th>
          </tr>
      </thead>
    
      <tbody class="bg-white" v-for="details in billDetails">
          <tr>                 
              <td class="text-center px-6 py-4 whitespace-no-wrap border-b border-gray-200">
                  
                  <div class="text-sm leading-5 text-gray-500">{{details.nameProduct}}</div>
              </td>
              <td class="text-center px-6 py-4 whitespace-no-wrap border-b border-gray-200">         
              <div class="text-sm leading-5 text-gray-500">{{details.marcaProduct}}</div>
              </td>
              <td class="text-center px-6 py-4 whitespace-no-wrap border-b border-gray-200">         
              <div class="text-sm leading-5 text-gray-500">{{details.volumProducto}}</div>
              </td>
              <td class="text-center px-6 py-4 whitespace-no-wrap border-b border-gray-200">         
              <div class="text-sm leading-5 text-gray-500">{{details.priceProduct}}</div>
              </td>
              <td class="text-center px-6 py-4 whitespace-no-wrap border-b border-gray-200">         
              <div class="text-sm leading-5 text-gray-500">{{details.cantProduct}}</div>
              </td>
              <td class="text-center px-6 py-4 whitespace-no-wrap border-b border-gray-200">         
              <div class="text-sm leading-5 text-gray-500">{{details.priceProduct * details.cantProduct}}</div>
              </td>
          </tr>
    
      </tbody>
    </table>  
    </div>
    </div>
  </div>
</div>
</div>
`

})


var app = new Vue({
  el: '#app',
  data: {
    message: 'Hello Vue!',
    category: 0,
    productsSupplier: [],
    filter: "",
    statusNav: false,
    car: 0
  },
  methods: {
    card() {
      let url = "../api/car.php";
      fetch(url)
        .then((response) => response.json())
        .then((result) => {
          if (result.status != 204) {

            this.car = result;
            /* console.log(result);
            console.log(this.car); */
          } else {
            this.car = {}
          }
          console.log(Object.keys(this.car).length);

        })
        .catch((error) => {
          console.log(error);
        })
    },
    getProducts() {
      fetch('../api/products.php?categoria=' + this.category)
        .then(response => response.json())
        .then(result => {
          if (result.status != 204) { this.productsSupplier = result }
          else {
            this.productsSupplier = {}
          }
        })
        .catch(error => {
          //console.log('hubo un error');
        })
    },
    formatPrice(value) {
      if (value == '') return "$ 0";
      let val = (value / 1).toFixed(2).replace('.', ',')
      return "$ " + val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".")
    },
    deleteProducts(idProduct) {
      let accion = confirm('Estas seguro que desea eliminar este producto')
      if (accion) {
        fetch('../api/products.php?idProducto=' + idProduct, {
          method: "DELETE",
        }).then(response => response.json())
          .then(result => {
            this.getProducts();
          })
          .catch(error => {
            console.log(error);
          })
      }

    }
  },
  computed: {
    searchProduct() {
      return this.productsSupplier.filter((item) => {
        return item.nameProduct.toLowerCase().includes(this.filter.toLowerCase())
      })
    },
    togleNav() {
      return this.statusNav ? 'block' : 'hidden';
    }
  },
  created() {
    this.getProducts();
    this.card();
  }
}

)


