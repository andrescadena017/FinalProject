<?php
include("../model/Admin.php");
$obj_admin = new Admin;

$id_shop = $_GET['shopId'];
$categoryId = $_GET['categoryId'];

$products = $obj_admin->getCategoryProducts($id_shop, $categoryId);

/* 
echo '<pre>';
var_dump($products); */



$principal_page = 'productsView';
include("../view/layout.php");
