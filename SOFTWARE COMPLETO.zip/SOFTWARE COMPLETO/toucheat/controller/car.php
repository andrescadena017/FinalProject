<?php
include("../model/Admin.php");
$result = null;
$obj_admin = new Admin;

if (isset($_GET['delete'])) {
    $id =  $_GET['id'];
    $obj_admin->deleteCar($id);
}
/* echo "<pre>";
var_dump($car); */
$car = $obj_admin->returnCar();

$principal_page = 'car';
include("../view/layout.php");
