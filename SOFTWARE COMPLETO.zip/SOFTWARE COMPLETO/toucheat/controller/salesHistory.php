<?php
include("../model/Admin.php");
$obj_admin = new Admin;


$principal_page = 'salesHistory';
include("../view/layout.php");