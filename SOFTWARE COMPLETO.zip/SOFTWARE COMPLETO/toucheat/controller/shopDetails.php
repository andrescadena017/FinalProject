<?php
include("../model/Admin.php");
$obj_admin = new Admin;

$id_shop = $_GET['id'];

$details = $obj_admin->getShopDetails($id_shop);
/* echo '<pre>';
var_dump($details['products']); */



$principal_page = 'shopDetails';
include("../view/layout.php");