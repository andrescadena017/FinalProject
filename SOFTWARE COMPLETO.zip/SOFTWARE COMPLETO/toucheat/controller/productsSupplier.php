<?php
include("../model/Admin.php");
$obj_admin = new Admin;
$categorias = $obj_admin->getCategories();

/* switch($_SERVER['REQUEST_METHOD']){
    case 'POST':s
        $error = $obj_admin->login($_POST['correo'],$_POST['password']);        
        break;
    default:
    break;
} */

$principal_page = 'productsSupplier';
include("../view/layout.php");
