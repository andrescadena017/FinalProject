<?php
include("../model/Admin.php");
$result= null;
$obj_admin = new Admin;
$departamentos = $obj_admin->get_all_table_data('departamentos', 'nameDto');
$municipios = $obj_admin->get_all_table_data('municipios', 'municipio');
$categoriasprov =$obj_admin->get_all_table_data('categoriasprov','nombreCat');




$principal_page = 'supplierDetails';
include("../view/layout.php");

