<?php
include("../model/Admin.php");
$result= null;
$obj_admin = new Admin;
$departamentos = $obj_admin->get_all_table_data('departamentos', 'nameDto');
$municipios = $obj_admin->get_all_table_data('municipios', 'municipio');
$categoriasprov =$obj_admin->get_all_table_data('categoriasprov','nombreCat');

switch ($_SERVER['REQUEST_METHOD']) {
    case 'POST':

         /* echo "<pre>";
        var_dump($_FILES);  */

    /* $_POST['nombre_del_campo'];*/

        $result = $obj_admin-> agregarProveedor ($_POST['userNombre'], $_POST['prNit'], $_POST['prRut'], $_POST['prEmail'], $_POST['prPass'], $_POST['prMobile'], $_POST['timeEnd'], $_POST['timeStart'] ,$_POST['idMunicipio'], $_POST['dirUser'],'2', $_POST['categoriaPro'], $_FILES['imgUrlProv']);
        break;
    default:
        break;
}

$principal_page = 'supplier_register';
include("../view/layout.php");
