<?php
include("../model/Admin.php");
$obj_admin = new Admin;

switch($_SERVER['REQUEST_METHOD']){
    case 'POST':
        $error = $obj_admin->login($_POST['correo'],$_POST['password']);        
        break;
    default:
    break;
}

$principal_page = 'login';
include("../view/layout.php");
