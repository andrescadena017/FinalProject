<?php
include("../model/Admin.php");
$obj_admin = new Admin;

/* echo "<pre>";
var_dump($_SESSION['supplierLog']['imgUrlProv']);
echo "</pre>"; */
$principal_page = 'dashsupplier';
include("../view/layout.php");
