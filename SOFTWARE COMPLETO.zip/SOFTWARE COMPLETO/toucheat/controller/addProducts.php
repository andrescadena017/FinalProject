<?php
include("../model/Admin.php");
$obj_admin = new Admin;
$categorias = $obj_admin->get_all_table_data('categorias', 'nameCategoria');


switch($_SERVER['REQUEST_METHOD']){
    case 'POST':
            
        $idProveedor =  $_SESSION['supplierLog']['idUsuario'];
       
         $error = $obj_admin->agregarProductos($_POST['nameProduct'],$_POST['marcaProduct'],$_POST['cantProducto'],
         $_POST['volumProducto'],$_POST['priceProduct'],$_POST['idCategoria'],$idProveedor, $_FILES['imgUrlProduct']);  
         
         
        
        break;
    default:
    break;
}

$principal_page = 'addProduct';
include("../view/layout.php");
