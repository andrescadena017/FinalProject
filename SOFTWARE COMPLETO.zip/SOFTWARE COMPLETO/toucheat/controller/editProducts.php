<?php
include("../model/Admin.php");
$obj_admin = new Admin;
$categorias = $obj_admin->get_all_table_data('categorias', 'nameCategoria');

$idProduct = $_GET['idproduct'];

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'POST':
        
        $sql = "UPDATE productos SET nameProduct = '".$_POST['nameProduct']."', marcaProduct = '".$_POST['marcaProduct']."', cantProducto = '".$_POST['cantProducto']."', volumProducto = '".$_POST['volumProducto']."', priceProduct = '".$_POST['priceProduct']."'";
        if ($_POST['idCategoria'] != '') {
            $sql .= ", idCategoria = '".$_POST['idCategoria']."' ";
        }
        if ($_FILES['newImage']['name']) {
            $imgUrlProv = $_FILES['newImage'];
            $origen = $imgUrlProv['tmp_name'];
            $ruta = "../files/" . $imgUrlProv['name'];
            if (!file_exists('../files')) {
                mkdir('../files', 0777, true);
            }
            move_uploaded_file($origen, $ruta);
            $sql .= ", imgUrlProduct = '$ruta'";
        }
        $sql .= " WHERE idProducto = '$idProduct'";        
        $response = $obj_admin->guardar($sql);
        break;
}

$sql = "SELECT * FROM productos 
        INNER JOIN categorias on productos.idCategoria = categorias.idCategoria
        WHERE idProducto = $idProduct";


$product = $obj_admin->exucute_sql($sql);
$principal_page = 'editProduct';
include("../view/layout.php");
