<?php
include("../model/Admin.php");
$obj_admin = new Admin;
$sql = "SELECT idUsuario, userNombre, imgUrlProv, categoriaPro, nombreCat, nombreCat as categoryName 
FROM toucheat.usuarios 
INNER JOIN categoriasprov 
ON usuarios.categoriaPro = categoriasprov.idcategoriasProv  
WHERE idRol = '2'";


$suppliers = $obj_admin->exucute_sql($sql);

/* echo "<pre>";
var_dump($suppliers);
echo "</pre>"; */

filtrar_array($suppliers, 'nombreCat');
/* echo "<pre>";
var_dump($suppliers);
echo "</pre>"; */


$principal_page = 'dashboard';
include("../view/layout.php");

function filtrar_array(&$array, $clave_orden) {
    $array_filtrado = array(); 
   
    foreach($array as $index=>$array_value) {
     
      $value = $array_value[$clave_orden];
      
      unset($array_value[$clave_orden]);
      
      $array_filtrado[$value][] = $array_value;
     
    }
    $array = $array_filtrado; 
  }