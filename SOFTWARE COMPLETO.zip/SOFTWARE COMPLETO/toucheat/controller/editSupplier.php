<?php
include("../model/Admin.php");
$obj_admin = new Admin;

$method = $_SERVER['REQUEST_METHOD'];






$idUser = $_GET['idUser'];
switch ($method) {
    case 'POST':
        //var_dump($_POST);   
        $sql = "UPDATE usuarios SET userNombre = '".$_POST['userNombre']."',userCorreo = '".$_POST['userCorreo']."',dirUser='".$_POST['dirUser']."',tel='".$_POST['tel']."',prNit='".$_POST['prNit']."',prRut='".$_POST['prRut']."',timeEnd='".$_POST['timeEnd']."',timeStart='".$_POST['timeStart']."'";
        
        if ($_FILES['newImage']['name']) {
            $imgUrlProv = $_FILES['newImage'];
            $origen = $imgUrlProv['tmp_name'];
            $ruta = "../files/" . $imgUrlProv['name'];
            if (!file_exists('../files')) {
                mkdir('../files', 0777, true);
            }
            move_uploaded_file($origen, $ruta);
            $sql .= ", imgUrlProv = '$ruta'";
        }
        $sql .= " WHERE idUsuario = '$idUser'";  
        $response = $obj_admin->guardar($sql); 
        break;
}

 $sql = "SELECT * FROM usuarios
 inner join municipios on usuarios.idMunicipio = municipios.idMunicipio
 inner join departamentos on municipios.idDepartamento = departamentos.idDto
 WHERE idUsuario='$idUser'; ";


$user = $obj_admin->exucute_sql($sql);
$_SESSION['supplierLog'] = $user[0];
$principal_page = 'editSupplier';
include("../view/layout.php");
