<?php
include("../model/Admin.php");
$result= null;
$obj_admin = new Admin;
$departamentos = $obj_admin->get_all_table_data('departamentos', 'nameDto');
$municipios = $obj_admin->get_all_table_data('municipios', 'municipio');

switch ($_SERVER['REQUEST_METHOD']) {
    
    case 'POST':
        /* echo "<pre>";
        var_dump($_POST); */
        $result = $obj_admin->agregarUsuario($_POST['userNombre'], $_POST['userApellido'], $_POST['userCorreo'], $_POST['userPass'], $_POST['fechaNaUser'], $_POST['dirUser'], $_POST['idMunicipio'], '1',$_POST['tel']);
        break;
    default:
        break;
}
$principal_page = 'user_register';
include("../view/layout.php");
