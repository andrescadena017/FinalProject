<?php
/* var_dump($_POST); */
header('Access-Control-Allow-Origin: *');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpMailer/Exception.php';
require 'phpMailer/PHPMailer.php';
require 'phpMailer/SMTP.php';

$nombre = $_POST['nombre'];
$email = $_POST['email'];
$body = $_POST['body'];
$subject = $_POST['subject'];
$front = $_FILES['front'];
if ($_FILES['back']['name']) $back = $_FILES['back'];

$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = 0;                      //Enable verbose debug output
    /* $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'info@iwebsigns.com';                     //SMTP username
    $mail->Password   = 'Colombia227.';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 465;  */
    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
    $mail->isSMTP();
    $mail->Host = 'localhost';
    $mail->SMTPAuth = false;
    $mail->SMTPAutoTLS = false;
    $mail->Port = 25;

    //Recipients
    $mail->setFrom($email, $nombre);
    //$mail->addAddress('info@iwebsigns.com', 'Web Signs');     //Add a recipient
    $mail->addAddress('websignsllc@gmail.com', 'Web Signs');     //Add a recipient

    $mail->AddAttachment($front['tmp_name'], $front['name']);
    if (isset($back)) $mail->AddAttachment($back['tmp_name'], $back['name']);
    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = $subject;
    $mail->Body    = $body;


    $mail->send();
    echo json_encode(['responsee' => 'Message has been sent']);
} catch (Exception $e) {
    echo json_encode(["response" => "Message could not be sent. Mailer Error: {$mail->ErrorInfo}"]);
}
