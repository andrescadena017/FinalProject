<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form id="form1" class="well col-lg-12" action="enviar.php" method="post" name="form1" enctype="multipart/form-data">
        <label>Nombre*</label>
        <input id="Nombre" type="text" name="Nombre" />

        <label>Email*</label>
        <input id="Email" type="email" name="Email" />

        <label>Mensaje*</label>
        <textarea id="Mensaje" name="Mensaje" rows="4"></textarea>

        <label>archivo</label>
        <input type="file" name="front" id="archivo-adjunto">
        <label>archivo</label>
        <input type="file" name="back" id="archivo-adjunto1">

        <button type="submit">Enviar</button>
    </form>
</body>

</html>