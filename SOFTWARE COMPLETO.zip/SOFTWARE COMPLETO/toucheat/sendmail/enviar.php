<?php
$Nombre = $_POST['Nombre'];
$Email = $_POST['Email'];
$Mensaje = $_POST['Mensaje'];
$front = $_FILES['front'];
if ($_FILES['back']['name']) $back = $_FILES['back'];


require("archivosmail/class.phpmailer.php");
$mail = new PHPMailer();


$mail->From     = $Email;
$mail->FromName = $Nombre;
$mail->AddAddress("info@iwebsigns.com");


$mail->WordWrap = 50;
$mail->IsHTML(true);
$mail->Subject  =  "Contacto";
$mail->Body     =  "Nombre: $Nombre \n<br />" .
    "Email: $Email \n<br />" .
    "Mensaje: $Mensaje \n<br />";
//$mail->AddAttachment($front['tmp_name'], $front['name']);
$mail->AddAttachment($front['tmp_name'], 'front');
if (isset($back)) $mail->AddAttachment($back['tmp_name'], 'back');


$mail->IsSMTP();
/* $mail->SMTPDebug = 2; */
$mail->Host = "ssl://smtp.gmail.com:465"; //Servidor de Salida.
$mail->SMTPAuth = true;
$mail->Username = "info@iwebsigns.com"; //Correo Electrónico
$mail->Password = "Colombia227."; //Contraseña

if ($mail->Send())
    echo json_encode(['response' => 'Mail sent successfully', 'status' => 200]);
else
    echo json_encode(['response' => 'The mail was not sent correctly', 'status' => 400]);
