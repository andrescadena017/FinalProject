<?php

class Admin
{
    function __construct()
    {
        session_start();
    }

    function retornarConexion()
    {
        return mysqli_connect('localhost', 'root', '', 'toucheat');
    }

    function deleteCar($id)
    {
        $exit = false;
        $sql = "DELETE FROM carrito  WHERE idCar = '$id'";

        $conection = $this->retornarConexion();
        $conection->query($sql);
        if ($conection->affected_rows > 0) {

            $exit = true;
        }
        $conection->close();

        return $exit;
    }

    function delete($tabla, $campo, $id)
    {
        $exit = false;
        $sql = "DELETE FROM $tabla  WHERE $campo = '$id'";

        $conection = $this->retornarConexion();
        $conection->query($sql);
        if ($conection->affected_rows > 0) {

            $exit = true;
        }
        $conection->close();

        return $exit;
    }
    function guardar($sql)
    {
        $exit = false;
        $conection = $this->retornarConexion();
        $conection->query($sql);
        if ($conection->affected_rows > 0) {
            $exit = true;
        }

        return $exit;
    }
    function get_all_table_data($table, $order = false)
    {
        $sql = "SELECT * FROM $table";
        if ($order) $sql .= " ORDER BY $order";
        $connection = $this->retornarConexion();
        $data = $connection->query($sql);
        if ($data != false) {
            $exit = $data->fetch_all(MYSQLI_ASSOC);
        } else {
            $exit = [];
        }
        $connection->close();
        return $exit;
    }

    function exucute_sql($sql)
    {
        $connection = $this->retornarConexion();
        $data = $connection->query($sql);
        if ($data != false) {
            $exit = $data->fetch_all(MYSQLI_ASSOC);
        } else {
            $exit = [];
        }
        $connection->close();
        return $exit;
    }

    function login($usuario, $password)
    {
        $exit = '';
        $connection = $this->retornarConexion();
        $sql = "SELECT * FROM usuarios
        inner join municipios on usuarios.idMunicipio = municipios.idMunicipio
        inner join departamentos on municipios.idDepartamento = departamentos.idDto
        WHERE userCorreo='$usuario';";
        $usuario = $connection->query($sql);
        if ($usuario) {
            $usuario = $usuario->fetch_all(MYSQLI_ASSOC);
            if (count($usuario) > 0) {
                if (password_verify($password, $usuario[0]['userPass'])) {
                    /* if ($password == $result[0]['password']) { */  //si la contraseña no esta encriptada 
                    switch ($usuario[0]['idRol']) {
                        case '1':
                            $_SESSION['buyer'] = $usuario[0];
                            header('location: store.php');
                            break;
                        case '2':
                            $_SESSION['supplierLog'] = $usuario[0];
                            header('location: dashSupplier.php');
                            break;
                    };
                } else {
                    $exit = 'La contraseña es incorrecta';
                }
            } else {
                $exit = 'El usuario no existe';
            }
        } else {
            $exit = 'Error en el servidor, por favor vuelve a intentarlo';
        }
        return $exit;
    }



    function agregarUsuario($userNombre, $userApellido, $userCorreo, $userPass, $fechaNaUser, $dirUser, $idMunicipio, $idRol, $tel)
    {
        $pass_encrypt = password_hash($userPass, PASSWORD_DEFAULT);
        $sql = "INSERT INTO usuarios (userNombre, userApellido, userCorreo, userPass, fechaNaUser, dirUser, idMunicipio, idRol, tel) 
                    VALUES ('$userNombre','$userApellido','$userCorreo','$pass_encrypt','$fechaNaUser','$dirUser','$idMunicipio','$idRol', '$tel')";
        $exit = $this->guardar($sql);
        return $exit;
    }


    function agregarProveedor($prName, $prNit, $prRut, $prEmail, $prPass, $prMobile, $timeEnd, $timeStart, $idMunicipio, $dirUser, $idRol, $categoriaPro, $imgUrlProv)
    {
        $origen = $imgUrlProv['tmp_name'];
        $ruta = "../files/" . $imgUrlProv['name'];
        if (!file_exists('../files')) {
            mkdir('../files', 0777, true);
        }
        if (move_uploaded_file($origen, $ruta)) {
            $pass_encrypt = password_hash($prPass, PASSWORD_DEFAULT);
            $sql = "INSERT INTO usuarios ( userNombre, prNit, prRut, userCorreo, userPass, tel, timeEnd, timeStart, idMunicipio, dirUser, idRol, categoriaPro, imgUrlProv)
                VALUES ('$prName', '$prNit', '$prRut', '$prEmail', '$pass_encrypt', '$prMobile', '$timeEnd', '$timeStart', '$idMunicipio','$dirUser' ,'$idRol', '$categoriaPro','$ruta')";
            $exit = $this->guardar($sql);
            return $exit;
        } else {
            return false;
        }
    }



    function agregarCategorias($nameCategoria, $imgCategoria)
    {
        $sql = "INSERT INTO categorias(nameCategoria, imgCategoria)
    VALUES ()";
    }



    function agregarProductos($nameProduct, $marcaProduct, $cantProducto, $volumProducto, $priceProduct, $idCategoria, $idProveedor, $imgUrlProduct)
    {
        $origen = $imgUrlProduct['tmp_name'];
        $destino = "../files/" . $imgUrlProduct['name'];
        if (!file_exists('../files/')) {
            mkdir('../files/', 0777, true);
        }
        if (move_uploaded_file($origen, $destino)) {
            $sql = " INSERT INTO productos (nameProduct, marcaProduct, cantProducto, volumProducto, priceProduct, idCategoria, idProveedor,imgUrlProduct) 
            values('$nameProduct','$marcaProduct','$cantProducto','$volumProducto','$priceProduct','$idCategoria','$idProveedor','$destino')";
            $exit = $this->guardar($sql);
            return $exit;
        } else {
            return false;
        }
    }
    function getCategoryProducts($id_shop, $categoryId)
    {
        $sql = "SELECT * FROM toucheat.productos WHERE idCategoria = $categoryId AND idProveedor = $id_shop;";
        $products = $this->exucute_sql($sql);
        return $products;
    }
    function getShopDetails($id_shop)
    {
        $sql = "SELECT * FROM toucheat.usuarios
         inner join municipios on usuarios.idMunicipio = municipios.idMunicipio
        inner join departamentos on municipios.idDepartamento = departamentos.idDto
         WHERE idUsuario = $id_shop;";
        $user = $this->exucute_sql($sql);

        $sql = "SELECT DISTINCT nameCategoria, categorias.idCategoria, imgCategoria, usuarios.idUsuario 
        FROM toucheat.usuarios 
        INNER JOIN productos 
        ON idProveedor = idUsuario 
        INNER JOIN categorias 
        ON categorias.idCategoria = productos.idCategoria 
        WHERE idProveedor = $id_shop;";
        $products = $this->exucute_sql($sql);

        //$products = $this->filtrar_array($products, 'nameCategoria');

        return ['user' => $user[0], 'products' => $products];
    }

    function filtrar_array(&$array, $clave_orden)
    {

        $array_filtrado = array();

        foreach ($array as $index => $array_value) {

            $value = $array_value[$clave_orden];

            unset($array_value[$clave_orden]);

            $array_filtrado[$value][] = $array_value;
        }
        $array = $array_filtrado;
        return $array;
    }
    function getCategories()
    {
        $sql = "SELECT * FROM toucheat.categorias WHERE idCategoria IN (SELECT idCategoria FROM productos WHERE idProveedor = '{$_SESSION['supplierLog']['idUsuario']}') ORDER BY nameCategoria;";
        return $this->exucute_sql($sql);
    }
    function getCar()
    {

        $sql = "SELECT * FROM carrito WHERE idComprador = {$_SESSION['buyer']['idUsuario']}";
        $exit = $this->exucute_sql($sql);
        return $exit;
    }
    function addToCar($id_producto, $cant_product)
    {
        $sql = "SELECT * FROM carrito WHERE idProducto = $id_producto";
        $response = $this->exucute_sql($sql);
        if (count($response) > 0) {
            $cant_product += $response[0]['cantProduct'];
            //var_dump($response);
            $id = $response[0]['idCar'];
            $sql = "UPDATE carrito SET cantProduct = '$cant_product' WHERE idCar = '$id'";
            $action = 'Update';
        } else {
            $sql = "INSERT INTO carrito(idProducto, cantProduct, idComprador) VALUES('$id_producto','$cant_product','{$_SESSION['buyer']['idUsuario']}')";
            $action = 'Insert';
        }
        //echo $sql;
        $exit = $this->guardar($sql);
        $car = $this->getCar();
        return ['status' => $exit, 'car' => $car, 'action' => $action, 'sql' => $sql];
    }

    function returnCar()
    {
        $sql = "SELECT car.idCar, car.cantProduct,prod.idProducto, prod.imgUrlProduct, user.userNombre,prod.nameProduct,prod.priceProduct, prod.idProveedor FROM carrito as car 
        INNER JOIN productos as prod
        ON prod.idProducto = car.idProducto 
        INNER JOIN usuarios as user
        ON prod.idProveedor = user.idUsuario WHERE car.idComprador  = '{$_SESSION['buyer']['idUsuario']}'";
        return $this->exucute_sql($sql);
    }
    /*     function comprobarClave(){
        prPass=document.f1.prPass.value;
        passTwo=document.f1.passTwo.value;

        if(prPass == passTwo)
        {
            return $exit;
            }

      else {
        alert("Contraseñas no coinciden")
    }

    } */
    function update_car($id_car, $cant_product)
    {
        $sql = "UPDATE carrito SET cantProduct = '$cant_product' WHERE idCar = '$id_car'";
        return $this->guardar($sql);
    }
    function newBill($id_factura, $address, $total)
    {
        $buyer = $_SESSION['buyer']['idUsuario'];
        $sql = "INSERT INTO factura (idFactura, idComprador, fechaFac, envioDir, totalFac, descuento) 
            VALUES ('$id_factura', '$buyer', NOW(), '$address', '$total', '0');";
        return $this->guardar($sql);
    }
    function Addbilldetails($billId, $billProducts)
    {
        foreach ($billProducts as $product) {
            $sql = "INSERT INTO billdetails (idProduct, cantProduct, priceProduct, idFactura) 
            VALUES ('$product->idProducto', '$product->cantProduct', '$product->priceProduct', '$billId');";
            //echo json_encode([$sql]);
            $this->guardar($sql);
            $sql = "DELETE FROM carrito WHERE idCar = $product->idCar;";
            //echo json_encode([$sql]);

            $this->guardar($sql);
        }
    }
}
