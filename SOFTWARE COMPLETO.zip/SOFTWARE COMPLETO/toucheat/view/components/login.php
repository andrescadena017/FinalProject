<div class="h-screen flex bg-gray-100">
    <div class="m-auto">
        <div class="cont-image w-5/12 md:w-2/12 m-auto pt-4">
            <img class="" src="../assets/img/logo.png" alt="">
        </div>
        <?php if (isset($error)) { ?>
            <div class="bg-red-50 p-4 rounded flex items-start text-red-600 my-4 shadow-lg mx-auto max-w-2xl">
                <div class="text-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" class="fill-current w-5 pt-1" viewBox="0 0 24 24">
                        <path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm4.597 17.954l-4.591-4.55-4.555 4.596-1.405-1.405 4.547-4.592-4.593-4.552 1.405-1.405 4.588 4.543 4.545-4.589 1.416 1.403-4.546 4.587 4.592 4.548-1.403 1.416z" />
                    </svg>
                </div>
                <div class=" px-3">
                    <h3 class="text-red-800 font-semibold tracking-wider">
                        Danger
                    </h3>
                    <ul class="list-disc list-inside">
                        <?php echo $error; ?>
                    </ul>
                </div>
            </div>
        <?php } ?>
        <form action="login.php" method="POST">
            <div class="w-9/12 m-auto">
                <div class="p-1 ">
                    <label class="" for="">Correo electrónico</label>
                    <input name="correo" class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent " type="email" placeholder="Correo electrónico" required>
                </div>
                <div class="p-1 ">
                    <label class="" for="">Contraseña</label>
                    <input name="password" class=" block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent " type="password" placeholder="introduce tu contraseña" required>
                </div>
                <div class="p-1 mt-4 w-full md:w-4/12 m-auto">
                    <input type="submit" value="INICIAR SESIÓN" class="py-3 bg-original text-white w-full rounded hover:bg-yellow-400 cursor-pointer font-bold">
                </div>
                <div class="p-1 mt-4 w-full md:w-4/12 m-auto flex">
                    <a href="#" class="text-center w-full underline">¿Has olvidado tu contraseña?</a>
                </div>
                <div class="p-1 flex justify-center">
                    <a href="supplierRegister.php" class="mx-1 text-center bg-transparent hover:bg-yellow-300 text-yellow-300 hover:text-white rounded shadow hover:shadow-lg py-2 px-4 border border-yellow-300 hover:border-transparent">
                        Nueva empresa</a>
                    <a href="userRegister.php" class="mx-1 text-center bg-transparent hover:bg-yellow-300 text-yellow-300 hover:text-white rounded shadow hover:shadow-lg py-2 px-4 border border-yellow-300 hover:border-transparent">
                        Nuevo usuario</a>
                </div>
            </div>
        </form>
    </div>
</div>