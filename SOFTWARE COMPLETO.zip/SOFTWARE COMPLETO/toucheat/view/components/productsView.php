<?php
include("navbarUser.php");
?>
<!-- component -->
<products-view v-on:load-card="card"></products-view>