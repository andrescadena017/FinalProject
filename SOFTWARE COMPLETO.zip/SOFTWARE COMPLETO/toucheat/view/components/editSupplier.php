<?php include 'navbar.php'; ?>
<form action="editSupplier.php?idUser=<?php echo $user[0]['idUsuario'] ?>" method="POST" enctype="multipart/form-data">
  <div class="grid mt-8 md:w-4/12 m-auto gap-8 grid-cols-1">
    <div class="flex flex-col ">
      <div class="bg-white shadow-md rounded-3xl p-5">
        <div class="flex flex-col sm:flex-row items-center">
          <h2 class="font-semibold text-lg mr-auto">Actualizar Datos</h2>
          <div class="w-full sm:w-auto sm:ml-auto mt-3 sm:mt-0"></div>
        </div>
        <div class="mt-5">
          <div class="form">
            <div class="md:space-y-2 mb-3">
              <div class="flex items-center py-6">
                <div class="w-20 h-20 mr-4 flex-none rounded-xl border overflow-hidden">
                  <img class="w-20 h-20 mr-4 object-cover" src="<?php echo $user[0]['imgUrlProv'] ?>" alt="Avatar Upload">
                </div>
                <label class="cursor-pointer ">
                  <span class="focus:outline-none text-white text-sm py-2 px-4 rounded-full bg-green-400 hover:bg-green-500 hover:shadow-lg">Browse</span>
                  <input type="file" class="hidden" :multiple="multiple" :accept="accept" name="newImage">
                </label>
              </div>
            </div>
            <div class="md:flex flex-row md:space-x-4 w-full text-xs">
              <div class="mb-3 space-y-2 w-full text-xs">
                <label class="font-semibold text-gray-600 py-2">Company Name <abbr title="required">*</abbr></label>
                <input placeholder="Company Name" class="appearance-none block w-full bg-grey-lighter text-grey-darker border border-grey-lighter rounded-lg h-10 px-4" required="required" type="text" name="userNombre" id="integration_shop_name" value="<?php echo $user[0]['userNombre'] ?>">
                <p class="text-red text-xs hidden">Please fill out this field.</p>
              </div>
              <div class="mb-3 space-y-2 w-full text-xs">
                <label class="font-semibold text-gray-600 py-2">Company Mail <abbr title="required">*</abbr></label>
                <input placeholder="Email ID" class="appearance-none block w-full bg-grey-lighter text-grey-darker border border-grey-lighter rounded-lg h-10 px-4" required="required" type="text" name="userCorreo" id="integration_shop_name" value="<?php echo $user[0]['userCorreo'] ?>">
                <p class="text-red text-xs hidden">Please fill out this field.</p>
              </div>
            </div>
            <div class="md:flex flex-row md:space-x-4 w-full text-xs">
              <div class="mb-3 space-y-2 w-full text-xs">
                <label class="font-semibold text-gray-600 py-2">N.I.T<abbr title="required">*</abbr></label>
                <input placeholder="Company NIT" class="appearance-none block w-full bg-grey-lighter text-grey-darker border border-grey-lighter rounded-lg h-10 px-4" required="required" type="text" name="prNit" id="integration_shop_name" value="<?php echo $user[0]['prNit'] ?>">
                <p class="text-red text-xs hidden">Please fill out this field.</p>
              </div>
              <div class="mb-3 space-y-2 w-full text-xs">
                <label class="font-semibold text-gray-600 py-2">R.U.T<abbr title="required">*</abbr></label>
                <input placeholder="Company RUT" class="appearance-none block w-full bg-grey-lighter text-grey-darker border border-grey-lighter rounded-lg h-10 px-4" required="required" type="text" name="prRut" id="integration_shop_name" value="<?php echo $user[0]['prRut'] ?>">
                <p class="text-red text-xs hidden">Please fill out this field.</p>
              </div>
            </div>
            <div class="w-full flex flex-col mb-3">
              <label class="font-semibold text-gray-600 py-2">Company Address</label>
              <input placeholder="Address" class="appearance-none block w-full bg-grey-lighter text-grey-darker border border-grey-lighter rounded-lg h-10 px-4" type="text" name="dirUser" id="integration_street_address" value="<?php echo $user[0]['dirUser'] ?>">
            </div>
            <div class="w-full flex flex-col mb-3">
              <label class="font-semibold text-gray-600 py-2">Company Tel</label>
              <input placeholder="Address" class="appearance-none block w-full bg-grey-lighter text-grey-darker border border-grey-lighter rounded-lg h-10 px-4" type="text" name="tel" id="integration_street_address" value="<?php echo $user[0]['tel'] ?>">
            </div>


            <!--    <div class="md:flex md:flex-row md:space-x-4 w-full text-xs">
          <div class="w-full flex flex-col mb-3">
              <label class="font-semibold text-gray-600 py-2">Location<abbr title="required">*</abbr></label>
              <select class="block w-full bg-grey-lighter text-grey-darker border border-grey-lighter rounded-lg h-10 px-4 md:w-full " required="required" name="integration[city_id]" id="integration_city_id">
                <option value="">Seleted location</option>
                <option value="">Cochin,KL</option>
                <option value="">Mumbai,MH</option>
                <option value="">Bangalore,KA</option>
              </select>
              <p class="text-sm text-red-500 hidden mt-3" id="error">Please fill out this field.</p>
            </div>
            <div class="w-full flex flex-col mb-3">
              <label class="font-semibold text-gray-600 py-2">Location<abbr title="required">*</abbr></label>
              <select class="block w-full bg-grey-lighter text-grey-darker border border-grey-lighter rounded-lg h-10 px-4 md:w-full " required="required" name="integration[city_id]" id="integration_city_id">
                <option value="">Seleted location</option>
                <option value="">Cochin,KL</option>
                <option value="">Mumbai,MH</option>
                <option value="">Bangalore,KA</option>
              </select>
              <p class="text-sm text-red-500 hidden mt-3" id="error">Please fill out this field.</p>
            </div>
          </div> -->

            <div class="md:flex md:flex-row md:space-x-4 w-full text-xs">
              <div class="w-full flex flex-col mb-3">
                <label class="font-semibold text-gray-600 py-2">Opening time</label>
                <input placeholder="Address" class="appearance-none block w-full bg-grey-lighter text-grey-darker border border-grey-lighter rounded-lg h-10 px-4" type="time" name="timeStart" id="integration_street_address" value="<?php echo $user[0]['timeStart'] ?>">
              </div>
              <div class="w-full flex flex-col mb-3">
                <label class="font-semibold text-gray-600 py-2">closing time</label>
                <input placeholder="Address" class="appearance-none block w-full bg-grey-lighter text-grey-darker border border-grey-lighter rounded-lg h-10 px-4" type="time" name="timeEnd" id="integration_street_address" value="<?php echo $user[0]['timeEnd'] ?>">
              </div>
            </div>



            <p class="text-xs text-red-500 text-right my-3">Required fields are marked with an
              asterisk <abbr title="Required field">*</abbr></p>
            <div class="mt-5 text-right md:space-x-3 md:block flex flex-col-reverse">
              <a href="dashSupplier.php" class="mb-2 md:mb-0 bg-white px-5 py-2 text-sm shadow-sm font-medium tracking-wider border text-gray-600 rounded-full hover:shadow-lg hover:bg-gray-100"> Cancel </a>
              <button class="mb-2 md:mb-0 bg-green-400 px-5 py-2 text-sm shadow-sm font-medium tracking-wider text-white rounded-full hover:shadow-lg hover:bg-green-500">Save</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</form>