<?php include 'navbar.php'; ?>
<style>
    .-z-1 {
        z-index: -1;
    }

    .origin-0 {
        transform-origin: 0%;
    }

    input:focus~label,
    input:not(:placeholder-shown)~label,
    textarea:focus~label,
    textarea:not(:placeholder-shown)~label,
    select:focus~label,
    select:not([value='']):valid~label {
        /* @apply transform; scale-75; -translate-y-6; */
        --tw-translate-x: 0;
        --tw-translate-y: 0;
        --tw-rotate: 0;
        --tw-skew-x: 0;
        --tw-skew-y: 0;
        transform: translateX(var(--tw-translate-x)) translateY(var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
        --tw-scale-x: 0.75;
        --tw-scale-y: 0.75;
        --tw-translate-y: -1.5rem;
    }

    input:focus~label,
    select:focus~label {
        /* @apply text-black; left-0; */
        --tw-text-opacity: 1;
        color: rgba(0, 0, 0, var(--tw-text-opacity));
        left: 0px;
    }
</style>

<div class="min-h-screen bg-gray-100 p-0 sm:p-12">
    <?php if (isset($response) && $response == 0) { ?>
        <div class="bg-red-50 p-4 rounded flex items-start text-red-600 my-1 shadow-lg mx-auto max-w-2xl">
            <div class="text-lg">
                <svg xmlns="http://www.w3.org/2000/svg" class="fill-current w-5 pt-1" viewBox="0 0 24 24">
                    <path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm4.597 17.954l-4.591-4.55-4.555 4.596-1.405-1.405 4.547-4.592-4.593-4.552 1.405-1.405 4.588 4.543 4.545-4.589 1.416 1.403-4.546 4.587 4.592 4.548-1.403 1.416z" />
                </svg>
            </div>
            <div class=" px-3">
                <h3 class="text-red-800 font-semibold tracking-wider">
                    Danger
                </h3>
                <ul class="list-disc list-inside">
                    El producto no fue actualizado, por favor vuelve a intentarlo.<br><a href="productsSupplier.php" class="font-semibold underline"> Consultar Productos</a>
                </ul>
            </div>
        </div>
    <?php } else if (isset($response) && $response == 1) {
    ?>
        <div class="bg-green-50 p-4 rounded flex items-start text-green-600 my-1 shadow-lg mx-auto max-w-2xl">
            <div class="text-lg">
            <svg class="fill-current w-5 pt-1" xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                     <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905 0 .714-.211 1.412-.608 2.006L7 11v9m7-10h-2M7 20H5a2 2 0 01-2-2v-6a2 2 0 012-2h2.5" />
                 </svg>
            </div>
            <div class=" px-3">
                <h3 class="text-green-800 font-semibold tracking-wider">
                    Success
                </h3>
                <ul class="list-disc list-inside">
                    El producto fue actualizado correctamente<a href="productsSupplier.php" class="font-semibold underline"> Consultar Productos</a>
                </ul>
            </div>
        </div>
    <?php
    } ?>
    <div class="mx-auto max-w-md px-6 py-12 bg-white border-0 shadow-lg sm:rounded-3xl">
        <h1 class="text-2xl font-bold mb-8">Actualiza tus productos</h1>
        <form id="form" novalidate action="editProducts.php?idproduct=<?php echo $product[0]['idProducto'] ?>" enctype="multipart/form-data" method="POST">


            <div class="relative z-0 w-full mb-5">
                <input type="text" name="nameProduct" placeholder=" " required class="pt-3 pb-2 block w-full px-0 mt-0 bg-transparent border-0 border-b-2 appearance-none focus:outline-none focus:ring-0 focus:border-black border-gray-200" value="<?php echo $product[0]['nameProduct'] ?>" />
                <label for="name" class="absolute duration-300 top-3 -z-1 origin-0 text-gray-500">Nombre del producto</label>
                <span class="text-sm text-red-600 hidden" id="error">Name is required</span>
            </div>

            <div class="relative z-0 w-full mb-5">
                <input value="<?php echo $product[0]['marcaProduct'] ?>" type="text" name="marcaProduct" placeholder=" " required class="pt-3 pb-2 block w-full px-0 mt-0 bg-transparent border-0 border-b-2 appearance-none focus:outline-none focus:ring-0 focus:border-black border-gray-200" />
                <label for="name" class="absolute duration-300 top-3 -z-1 origin-0 text-gray-500">Fabricante</label>
                <span class="text-sm text-red-600 hidden" id="error">Fabricante is required</span>
            </div>

            <div class="relative z-0 w-full mb-5">
                <input value="<?php echo $product[0]['cantProducto'] ?>" type="text" name="cantProducto" placeholder=" " required class="pt-3 pb-2 pr-12 block w-full px-0 mt-0 bg-transparent border-0 border-b-2 appearance-none focus:outline-none focus:ring-0 focus:border-black border-gray-200" />
                <div class="absolute top-0 right-0 mt-3 mr-4 text-gray-400">Unidades</div>
                <label for="duration" class="absolute duration-300 top-3 -z-1 origin-0 text-gray-500">Unidades disponibles</label>
                <span class="text-sm text-red-600 hidden" id="error">Unidades is required</span>
            </div>



            <div class="relative z-0 w-full mb-5">
                <input value="<?php echo $product[0]['volumProducto'] ?>" type="text" name="volumProducto" placeholder=" " class="pt-3 pb-2 pr-12 block w-full px-0 mt-0 bg-transparent border-0 border-b-2 appearance-none focus:outline-none focus:ring-0 focus:border-black border-gray-200" />
                <div class="absolute top-0 right-0 mt-3 mr-4 text-gray-400">Gr, ml, cm3</div>
                <label for="duration" class="absolute duration-300 top-3 -z-1 origin-0 text-gray-500">Volumen por producto</label>
                <span class="text-sm text-red-600 hidden" id="error">Volumen is required</span>
            </div>


            <p class="pt-2"> Categoria actual: <?php echo $product[0]['nameCategoria'] ?></p>
            <div class="relative z-0 w-full mb-5">

                <select name="idCategoria" value="" onclick="this.setAttribute('value', this.value);" class="pt-3 pb-2 block w-full px-0 mt-0 bg-transparent border-0 border-b-2 appearance-none z-1 focus:outline-none focus:ring-0 focus:border-black border-gray-200">
                    <option default></option>
                    <?php
                    foreach ($categorias as $proveedor) {
                    ?>
                        <option value="<?php echo $proveedor['idCategoria']; ?>"><?php echo $proveedor['nameCategoria']; ?></option>
                    <?php
                    }
                    ?>
                </select>
                <label for="select" class="absolute duration-300 top-3 -z-1 origin-0 text-gray-500">Select an option</label>
                <span class="text-sm text-red-600 hidden" id="error">Option has to be selected</span>
            </div>


            <div class="relative z-0 w-full mb-5">
                <input value="<?php echo $product[0]['priceProduct'] ?>" type="number" name="priceProduct" placeholder=" " class="pt-3 pb-2 pl-5 block w-full px-0 mt-0 bg-transparent border-0 border-b-2 appearance-none focus:outline-none focus:ring-0 focus:border-black border-gray-200" />
                <div class="absolute top-0 left-0 mt-3 ml-1 text-gray-400">$</div>
                <label for="money" class="absolute duration-300 top-3 left-5 -z-1 origin-0 text-gray-500">Precio por unidad</label>
            </div>

            <div class="flex-shrink-0  w-full">
                <img src="<?php echo $product[0]['imgUrlProduct'] ?>" class="w-full h-full">
            </div>
            <div class="relative z-0 w-full mb-5">
                    <input type="file" name="newImage">
            </div>

            <button id="button" type="Submit" class="w-full px-6 py-3 mt-3 text-lg text-white transition-all duration-150 ease-linear rounded-lg shadow outline-none bg-yellow-500 hover:bg-yellow-600 hover:shadow-lg focus:outline-none">
                Actualizar Producto
            </button>
        </form>
    </div>
</div>