<?php

include 'navbarUser.php';
?>

<carrito-component v-bind:car="car" v-on:reload="card()"></carrito-component>