<div class="p-1">
    <div class="cont-image w-5/12 md:w-2/12 m-auto pt-4">
        <img class="" src="../assets/img/logo.png" alt="">
    </div>
    <?php if ($result === null || $result == false) { ?>
        <h1 class="text-center text-5xl mb-5">Registra tu empresa en Touch Eat</h1>
        <?php if ($result === false) { ?>
            <div class="bg-yellow-50 p-4 rounded flex items-start text-yellow-600 my-4 shadow-lg mx-auto max-w-2xl">
                <div class="text-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" class="fill-current w-5 pt-1" viewBox="0 0 24 24">
                        <path d="M12 1l-12 22h24l-12-22zm-1 8h2v7h-2v-7zm1 11.25c-.69 0-1.25-.56-1.25-1.25s.56-1.25 1.25-1.25 1.25.56 1.25 1.25-.56 1.25-1.25 1.25z" />
                    </svg>
                </div>
                <div class=" px-3">
                    <h3 class="text-yellow-800 font-semibold tracking-wider">
                        No se ha registrado el usuario
                    </h3>
                    <p class="pt-2 text-yellow-700">
                        Ha ocurrido un error y no se ha registrado el usuario, vuelve a intentarlo
                    </p>
                </div>
            </div>
        <?php } ?>
        <form action="supplierRegister.php" method="POST" name="f1" enctype="multipart/form-data">
            <div class="w-9/12 m-auto">

                <div class="block md:flex">

                    <div class="block p-1 w-full md:w-6/12">
                    <label class="" for="">Nombre de la empresa</label>
                    <input name=" userNombre" class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent " type="text" placeholder="introduce nombre de tu empresa" required>
                    </div>
                    <div class="block p-1 w-full md:w-6/12">
                        <label class="" for="">Clasificación</label>
                        <select name="categoriaPro" id="" class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent ">
                            <?php
                            foreach ($categoriasprov as $proveedor) {
                            ?>
                                <option value="<?php echo $proveedor['idcategoriasProv']; ?>"><?php echo $proveedor['nombreCat']; ?></option>
                            <?php
                            }
                            ?>
                        </select>

                    </div>

                </div>

                <div class="block md:flex">
                    <div class="block p-1 w-full md:w-6/12">
                        <label class="" for="">N.I.T de la empresa</label>
                        <input name="prNit" class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent " type="number" placeholder="introduce el N.I.T (Opcional)" required>
                    </div>

                    <div class="block p-1 w-full md:w-6/12">
                        <label class="" for="">R.U.T de la empresa</label>
                        <input name="prRut" class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent " type="text" placeholder="introduce el R.U.T (Opcional)" required>
                    </div>
                </div>

                <div class="p-1 ">
                    <label class="" for="">Cuál es el correo empresarial</label>
                    <input name="prEmail" class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent " type="email" placeholder="introduce el correo empresarial" required>
                </div>
                <div class="p-1 ">
                    <label class="" for="">Confirmar el correo empresarial</label>
                    <input class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent " type="email" placeholder="Vuelve a introducir el correo empresarial" required>
                </div>

                <div class="block md:flex">
                    <div class="block p-1 w-full md:w-6/12">
                        <label class="" for="">Cuál es tu contraseña</label>
                        <input name="prPass" class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent " type="password" placeholder="introduce tu contraseña" minlength="6" required>
                    </div>
                    <div class="block p-1 w-full md:w-6/12">
                        <label class="" for="">Confirma tu contraseña</label>
                        <input name="passTwo" class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent " type="password" placeholder="Vuelve a introducir tu contraseña" required>
                    </div>
                </div>
                <div class="block md:flex">
                    <div class="p-1 w-full md:w-6/12">
                        <label class="" for="">Hora de apertura</label>
                        <input name="timeStart" class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent " type="time" required>
                    </div>
                    <div class="p-1 w-full md:w-6/12">
                        <label class="" for="">Hora de cerrar</label>
                        <input name="timeEnd" class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent " type="time" required>
                    </div>
                </div>

                <div class="block md:flex">
                    <div class="block p-1 w-full md:w-6/12">
                        <label class="" for="">Departamento</label>
                        <select name="" id="" class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent ">
                            <?php
                            foreach ($departamentos as $departamento) {
                            ?>
                                <option value=""><?php echo $departamento['nameDto']; ?></option>
                            <?php
                            }
                            ?>
                        </select>
                    </div>
                    <div class="block p-1 w-full md:w-6/12">
                        <label class="" for="">Municipio</label>
                        <select name="idMunicipio" id="" class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent ">
                            <?php
                            foreach ($municipios as $municipio) {
                            ?>
                                <option value="<?php echo $municipio['idMunicipio']; ?>"><?php echo $municipio['municipio']; ?></option>
                            <?php
                            }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="block md:flex">

                    <div class="p-1 w-full ">
                        <label class="" for="">ingresa dirección de la empresa</label>
                        <input name="dirUser" class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent " type="text" placeholder="Ingresa la dirección" required>
                    </div>


                    <div class="p-1 w-full ">
                        <label class="" for="">Cuál es el teléfono empresarial </label>
                        <input name="prMobile" class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent " type="number" placeholder="Número de teléfono empresarial" minlength="7" required>
                    </div>
                </div>
                <div class="flex w-full items-center justify-center bg-grey-lighter">
                    <label class="w-64 flex flex-col items-center px-4 py-6 bg-white text-blue rounded-lg shadow-lg tracking-wide uppercase border border-blue cursor-pointer hover:bg-blue hover:text-white">
                        <svg class="w-8 h-8" fill="currentColor" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                            <path d="M16.88 9.1A4 4 0 0 1 16 17H5a5 5 0 0 1-1-9.9V7a3 3 0 0 1 4.52-2.59A4.98 4.98 0 0 1 17 8c0 .38-.04.74-.12 1.1zM11 11h3l-4-4-4 4h3v3h2v-3z" />
                        </svg>
                        <span class="mt-2 text-base leading-normal">select a profile picture</span>
                        <input name='imgUrlProv' type='file' class="hidden" />
                    </label>
                </div>
                <div class="p-1 mt-4">
                    <input type="submit" value="REGÍSTRATE" class="py-3 bg-original text-white w-full rounded hover:bg-yellow-400 cursor-pointer font-bold">
                </div>
                <div class="p-1 flex mb-5">
                    <a href="login.php" class="w-full text-center m-auto underline">INICIAR SESIÓN</a>
                </div>
            </div>
        </form>
    <?php } else { ?>
        <div class="space-x-2 bg-green-50 rounded flex items-start text-green-600 my-4 mx-auto max-w-2xl shadow-lg">
            <div class="w-1 self-stretch bg-green-800">

            </div>
            <div class="flex  space-x-2 p-4">
                <svg class="fill-current w-5 pt-1" xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905 0 .714-.211 1.412-.608 2.006L7 11v9m7-10h-2M7 20H5a2 2 0 01-2-2v-6a2 2 0 012-2h2.5" />
                </svg>
                <h3 class="text-green-800 tracking-wider flex-1">
                    Se ha registrado el usuario correctamente <a href="login.php" class="font-semibold underline"> Iniciar Sesión </a>
                </h3>
            </div>
        </div>
    <?php } ?>
</div>