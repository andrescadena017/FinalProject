<?php
include("navbarUser.php");
?>
<div class="container mx-auto px-4 sm:px-8">
    <pedidos></pedidos>
</div>