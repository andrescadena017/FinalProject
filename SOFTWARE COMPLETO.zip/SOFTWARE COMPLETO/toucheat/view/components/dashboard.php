<?php

include 'navbarUser.php';

?>

<main class="flex-grow flex justify-center items-center">

    <div class="mx-auto px-4 sm:px-8 py-2 text-center w-full">
        <?php foreach ($suppliers as $supplier) { ?>
            <div class="text-center max-w-lg mx-auto mt-6">
                <div class="  block mx-auto rounded-sm font-semibold text-gray-700 text-2xl "><?php echo $supplier[0]['categoryName'] ?></div>
            </div>
            <!-- <div class="items-start mt-2 mx-auto   max-w-full w-full flex overflow-auto"> -->
            <div class="flex overflow-auto">
                <?php foreach ($supplier as $category) {
                ?>
                    <div class="custom-scroll h-full m-auto md:m-1 p-1">
                        <div class="bg-white w-full shadow-lg rounded-lg px-4 py-6 mx-4 my-4">
                            <div class="mx-auto h-40 bg-gray-200 rounded-md flex w-max overflow-hidden">
                                <?php if ($category['imgUrlProv'] == null) { ?>
                                    <svg class="w-3/12 m-auto text-gray-400" xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                    </svg>
                                <?php } else { ?>
                                    <img class="m-auto max-h-40" src="<?php echo $category['imgUrlProv'] ?>" alt="">
                                <?php } ?>
                            </div>
                            <div class=" w-full mt-8 block mx-auto rounded-sm"><?php echo $category['userNombre'] ?></div>
                            <!-- <div class="h-2 bg-gray-200 w-10/12 mt-2 block mx-auto rounded-sm"></div> -->
                            <div class="flex justify-center mt-4">
                                <!-- <div class="rounded-sm h-8 w-20 px-4 bg-gray-200 mr-2"></div> -->
                                <a href="shopDetails.php?id=<?php echo $category['idUsuario']; ?> " class="rounded-sm  w-5/12 p-1 bg-yellow-500 hover:bg-yellow-600 text-white font-bold">Visitar</a>
                            </div>
                        </div>
                    </div>

                <?php } ?>
            </div>
        <?php } ?>
    </div>

</main>