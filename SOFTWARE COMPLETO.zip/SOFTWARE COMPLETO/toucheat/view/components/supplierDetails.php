<?php

include 'navbarUser.php';

?>

<div>

<div class=" px-1 py-6 shadow-sm rounded-md bg-white">

<img src="<?php echo $_SESSION['supplierLog'][''] ?>" class="object-cover w-full h-full" alt="avatar">

<div class="flex items-center py-1 ">
    <div class="flex items-center">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
        </svg>
    </div>
    <p class="text-gray-500 text-sm pl-1"><?php echo $_SESSION['supplierLog']['userCorreo'] ?></p>
</div>
<div class="flex items-center py-1">
    <div class="">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
        </svg>
    </div>
    <p class="text-gray-500 text-sm pl-1"><?php echo $_SESSION['supplierLog']['tel'] ?></p>
</div>

<div class="flex items-center py-1">
    <div class="">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
    </div>
    <p class="text-gray-500 text-sm pl-1"><?php echo $_SESSION['supplierLog']['dirUser'] ?></p>
</div>

<div class="flex items-center py-1">
    <div class="">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
        </svg>
    </div>
    <p class="text-gray-500 text-sm pl-1"><?php echo $_SESSION['supplierLog']['municipio'] . ", " . $_SESSION['supplierLog']['nameDto']  ?></p>
</div>
<div class="flex py-1 items-center">
    <div class="">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-500" viewBox="0 0 20 20" fill="currentColor">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clip-rule="evenodd" />
        </svg>
    </div>
    <p class="text-gray-500 text-sm pl-1"><?php echo $_SESSION['supplierLog']['timeStart'] ?></p>
</div>
<div class="flex items-center py-1">
    <div class="">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
    </div>
    <p class="text-gray-500 text-sm pl-1"><?php echo $_SESSION['supplierLog']['timeEnd'] ?></p>
</div>

<div class="flex items-center py-1">
    <div class=" text-gray-500">
        <h5 class="">Nit.</h5>
    </div>
    <p class="text-gray-500 text-sm pl-1"><?php echo $_SESSION['supplierLog']['prNit'] ?></p>
</div>

<div class="flex items-center py-1">
    <div class=" text-gray-500">
        <h5 class="">Rut.</h5>
    </div>
    <p class="text-gray-500 text-sm pl-1"><?php echo $_SESSION['supplierLog']['prRut'] ?></p>
</div>

</div>
</div>


</div>



<main class="flex-grow flex justify-center items-center">

    <div class="mx-auto px-4 sm:px-8 py-2 text-center w-full">
        <?php foreach ($suppliers as $supplier) { ?>
            <div class="text-center max-w-lg mx-auto mt-6">
                <div class="  block mx-auto rounded-sm font-semibold text-gray-700 text-2xl "><?php echo $supplier[0]['categoryName'] ?></div>
            </div>
            <!-- <div class="items-start mt-2 mx-auto   max-w-full w-full flex overflow-auto"> -->
            <div class="flex overflow-auto">
                <?php foreach ($supplier as $category) {
                ?>
                    <div class="custom-scroll h-full m-auto md:m-1 p-1">
                        <div class="bg-white w-full shadow-lg rounded-lg px-4 py-6 mx-4 my-4">
                            <div class="mx-auto h-40 bg-gray-200 rounded-md flex w-max overflow-hidden">
                                <?php if ($category['imgUrlProv'] == null) { ?>
                                    <svg class="w-3/12 m-auto text-gray-400" xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                    </svg>
                                <?php } else { ?>
                                    <img class="m-auto max-h-40" src="<?php echo $category['imgUrlProv'] ?>" alt="">
                                <?php } ?>
                            </div>
                            <div class=" w-full mt-8 block mx-auto rounded-sm"><?php echo $category['userNombre'] ?></div>
                            <!-- <div class="h-2 bg-gray-200 w-10/12 mt-2 block mx-auto rounded-sm"></div> -->
                            <div class="flex justify-center mt-4">
                                <!-- <div class="rounded-sm h-8 w-20 px-4 bg-gray-200 mr-2"></div> -->
                                <a href="#" class="rounded-sm  w-5/12 p-1 bg-yellow-500 hover:bg-yellow-600 text-white font-bold">Visitar</a>
                            </div>
                        </div>
                    </div>

                <?php } ?>
            </div>
        <?php } ?>
    </div>

</main>