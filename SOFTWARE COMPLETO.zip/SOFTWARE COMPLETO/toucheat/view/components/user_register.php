<div class="p-1">
    <div class="cont-image w-5/12 md:w-2/12 m-auto pt-4">
        <img class="" src="../assets/img/logo.png" alt="">
    </div>
    <?php if ($result === null || $result == false) { ?>
        <h1 class="text-center text-5xl mb-5">Regístrate gratis en Touch Eat</h1>
        <?php if ($result === false) { ?>
            <div class="bg-yellow-50 p-4 rounded flex items-start text-yellow-600 my-4 shadow-lg mx-auto max-w-2xl">
                <div class="text-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" class="fill-current w-5 pt-1" viewBox="0 0 24 24">
                        <path d="M12 1l-12 22h24l-12-22zm-1 8h2v7h-2v-7zm1 11.25c-.69 0-1.25-.56-1.25-1.25s.56-1.25 1.25-1.25 1.25.56 1.25 1.25-.56 1.25-1.25 1.25z" />
                    </svg>
                </div>
                <div class=" px-3">
                    <h3 class="text-yellow-800 font-semibold tracking-wider">
                        No se ha registrado el usuario
                    </h3>
                    <p class="pt-2 text-yellow-700">
                        Ha ocurrido un error y no se ha registrado el usuario, vuelve a intentarlo
                    </p>
                </div>
            </div>
        <?php } ?>
        <form action="userRegister.php" method="POST">
            <div class="w-9/12 m-auto">
                <div class="block md:flex">
                    <div class="block p-1 w-full md:w-6/12">
                        <label class="" for="">Cuál es tu nombre</label>
                        <input name="userNombre" class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent " type="text" placeholder="introduce tu nombre" required>
                    </div>
                    <div class="block p-1 w-full md:w-6/12">
                        <label class="" for="">Cuál es tu apellido</label>
                        <input name="userApellido" class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent " type="text" placeholder="introduce tu apellido" required>
                    </div>
                </div>
                <div class="p-1 ">
                    <label class="" for="">Cuál es tu correo</label>
                    <input name="userCorreo" class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent " type="email" placeholder="introduce tu correo" required>
                </div>
                <div class="p-1 ">
                    <label class="" for="">Confirmar tu correo</label>
                    <input class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent " type="email" placeholder="Vuelve a introducir tu correo" required>
                </div>
                <div class="block md:flex">
                    <div class="block p-1 w-full md:w-6/12">
                        <label class="" for="">Cuál es tu contraseña</label>
                        <input name="userPass" class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent " type="password" placeholder="introduce tu contraseña" required>
                    </div>
                    <div class="block p-1 w-full md:w-6/12">
                        <label class="" for="">Confirma tu contraseña</label>
                        <input class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent " type="password" placeholder="Vuelve a introducir tu contraseña" required>
                    </div>
                </div>
                <div class="block md:flex">
                    <div class="p-1 w-full md:w-6/12">
                        <label class="" for="">Cuál es tu fecha de nacimiento</label>
                        <input name="fechaNaUser" class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent " type="date" required>
                    </div>
                    <div class="p-1 w-full md:w-6/12">
                        <label class="" for="">Cuál es tu teléfono</label>
                        <input name="tel" class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent " type="number" placeholder="Número de teléfono" minlength="10" required>
                    </div>
                </div>
                <div class="block md:flex">
                    <div class="block p-1 w-full md:w-6/12">
                        <label class="" for="">Departamento</label>
                        <select name="" id="" class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent ">
                            <?php
                            foreach ($departamentos as $departamento) {
                            ?>
                                <option value=""><?php echo $departamento['nameDto']; ?></option>
                            <?php
                            }
                            ?>
                        </select>
                    </div>
                    <div class="block p-1 w-full md:w-6/12">
                        <label class="" for="">Municipio</label>
                        <select name="idMunicipio" id="" class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent ">
                            <?php
                            foreach ($municipios as $municipio) {
                            ?>
                                <option value="<?php echo $municipio['idMunicipio']; ?>"><?php echo $municipio['municipio']; ?></option>
                            <?php
                            }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="p-1 ">
                    <label class="" for="">ingresa tu dirección</label>
                    <input name="dirUser" class="block w-full p-2 border rounded border-gray-300 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-transparent " type="text" placeholder="Ingresa la dirección" required>
                </div>

                <!-- <div class="flex w-full  items-center justify-center bg-grey-lighter">
                    <label class="w-64 flex flex-col items-center px-4 py-6 bg-white text-blue rounded-lg shadow-lg tracking-wide uppercase border border-blue cursor-pointer hover:bg-blue hover:text-white">
                        <svg class="w-8 h-8" fill="currentColor" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                            <path d="M16.88 9.1A4 4 0 0 1 16 17H5a5 5 0 0 1-1-9.9V7a3 3 0 0 1 4.52-2.59A4.98 4.98 0 0 1 17 8c0 .38-.04.74-.12 1.1zM11 11h3l-4-4-4 4h3v3h2v-3z" />
                        </svg>
                        <span class="mt-2 text-base leading-normal">select a profile picture</span>
                        <input name=  'imgUrlUser' type='file' class="hidden" />
                    </label>
                </div> -->

                <div class="grid grid-cols-1 mt-5 mx-7">
                    <label class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold mb-1">Upload Photo</label>
                    <div class='flex items-center justify-center w-full'>
                        <label class='flex flex-col border-4 border-dashed w-full h-32 hover:bg-gray-100 hover:border-purple-300 group'>
                            <div class='flex flex-col items-center justify-center pt-7'>
                                <svg class="w-10 h-10 text-purple-400 group-hover:text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                </svg>
                                <p class='lowercase text-sm text-gray-400 group-hover:text-purple-600 pt-1 tracking-wider'>Select a photo</p>
                            </div>
                            <input type='file' class="" />
                        </label>
                    </div>
                </div>

                <div class="p-1 mt-4">
                    <input type="submit" value="REGÍSTRATE" class="py-3 bg-original text-white w-full rounded hover:bg-yellow-400 cursor-pointer font-bold">
                </div>
                <div class="p-1 flex mb-5">
                    <a href="login.php" class="w-full text-center m-auto underline">INICIAR SESIÓN</a>
                </div>
            </div>
        </form>
    <?php } else { ?>
        <div class="space-x-2 bg-green-50 rounded flex items-start text-green-600 my-4 mx-auto max-w-2xl shadow-lg">
            <div class="w-1 self-stretch bg-green-800">

            </div>
            <div class="flex  space-x-2 p-4">
                <svg class="fill-current w-5 pt-1" xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905 0 .714-.211 1.412-.608 2.006L7 11v9m7-10h-2M7 20H5a2 2 0 01-2-2v-6a2 2 0 012-2h2.5" />
                </svg>
                <h3 class="text-green-800 tracking-wider flex-1">
                    Se ha registrado el usuario correctamente <a href="login.php" class="font-semibold underline"> Iniciar Sesión </a>
                </h3>
            </div>
        </div>
    <?php } ?>
</div>