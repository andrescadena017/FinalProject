<?php
include("navbar.php");
?>

<main class="flex bg-gray-200 h-screen">
    <div class=" hidden md:block w-2/12">
        <div class="w-full py-6 pl-2">
            <div class=" px-1 py-6 shadow-sm rounded-md bg-white">

                <img src="<?php echo $_SESSION['supplierLog']['imgUrlProv'] ?>" class="object-cover w-full h-full" alt="avatar">

                <div class="flex items-center py-1 ">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                        </svg>
                    </div>
                    <p class="text-gray-500 text-sm pl-1"><?php echo $_SESSION['supplierLog']['userCorreo'] ?></p>
                </div>
                <div class="flex items-center py-1">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                        </svg>
                    </div>
                    <p class="text-gray-500 text-sm pl-1"><?php echo $_SESSION['supplierLog']['tel'] ?></p>
                </div>

                <div class="flex items-center py-1">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                    </div>
                    <p class="text-gray-500 text-sm pl-1"><?php echo $_SESSION['supplierLog']['dirUser'] ?></p>
                </div>

                <div class="flex items-center py-1">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                        </svg>
                    </div>
                    <p class="text-gray-500 text-sm pl-1"><?php echo $_SESSION['supplierLog']['municipio'] . ", " . $_SESSION['supplierLog']['nameDto']  ?></p>
                </div>
                <div class="flex py-1 items-center">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-500" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clip-rule="evenodd" />
                        </svg>
                    </div>
                    <p class="text-gray-500 text-sm pl-1"><?php echo $_SESSION['supplierLog']['timeStart'] ?></p>
                </div>
                <div class="flex items-center py-1">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>

                        <p class="text-gray-500 text-sm pl-1"><?php echo $_SESSION['supplierLog']['timeEnd'] ?></p>
                    </div>
                </div>

                <div class="flex items-center py-1">
                    <div class=" text-gray-500">
                        <h5 class="">Nit.</h5>
                    </div>
                    <p class="text-gray-500 text-sm pl-1"><?php echo $_SESSION['supplierLog']['prNit'] ?></p>
                </div>

                <div class="flex items-center py-1">
                    <div class=" text-gray-500">
                        <h5 class="">Rut.</h5>
                    </div>
                    <p class="text-gray-500 text-sm pl-1"><?php echo $_SESSION['supplierLog']['prRut'] ?></p>
                </div>
                <div class="flex">
                    <button class="inline-block m-auto px-6 py-2 text-xs font-medium leading-6 text-center text-white uppercase transition bg-indigo-500 rounded shadow ripple hover:shadow-lg hover:bg-indigo-600 focus:outline-none">
                        <a href="editSupplier.php?idUser=<?php echo $_SESSION['supplierLog']['idUsuario'] ?>"> Editar </a>
                    </button>
                </div>
            </div>

        </div>
    </div>
    <div class="w-full md:w-10/12 flex-1 overflow-x-hidden overflow-y-auto ">
        <div class="container mx-auto px-6 py-8">
            <h3 class="text-gray-700 text-3xl font-medium">Dashboard</h3>

            <div class="mt-4">
                <div class="flex flex-wrap -mx-6">
                    <div class="w-full mt-6 px-6 sm:w-1/2 xl:w-1/2 sm:mt-0">
                        <div class="flex items-center px-5 py-6 shadow-sm rounded-md bg-white">
                            <div class="p-3 rounded-full bg-indigo-600 bg-opacity-75">
                                <!-- <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 m-auto" viewBox="0 0 28 30" fill="currentColor">
                                    <path d="M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM14 11a1 1 0 011 1v1h1a1 1 0 110 2h-1v1a1 1 0 11-2 0v-1h-1a1 1 0 110-2h1v-1a1 1 0 011-1z" />
                                    
                                </svg> -->
                            </div>

                            <div class="mx-5">
                                <a class="text-gray-500 text-2xl" href="addProducts.php">Agregar Productos</a>
                            </div>
                        </div>
                    </div>

                    <!-- <div class="w-full mt-6 px-6 sm:w-1/2 xl:w-1/3 sm:mt-0">
                        <div class="flex items-center px-5 py-6 shadow-sm rounded-md bg-white">
                            <div class="p-3 rounded-full bg-yellow-600 bg-opacity-75">
                            </div>
                            <div class="mx-5">
                                <a class="text-gray-500 text-2xl" href="salesHistory.php">Historial de Ventas</a>
                            </div>
                        </div>
                    </div> -->

                    <div class="w-full mt-6 px-6 sm:w-1/2 xl:w-1/2 sm:mt-0">
                        <div class="flex items-center px-5 py-6 shadow-sm rounded-md bg-white">
                            <div class="p-3 rounded-full bg-green-600 bg-opacity-75">

                            </div>

                            <div class="mx-5">
                                <a class="text-gray-500 text-2xl" href="productsSupplier.php">Ver Productos</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mt-8">

            </div>

            <div class="flex flex-col mt-8">
                <div class="-my-2 py-2 overflow-x-auto sm:-mx-6 sm:px-6 lg:-mx-8 lg:px-8">
                    <div class="align-middle inline-block min-w-full shadow overflow-hidden sm:rounded-lg border-b border-gray-200">
                        <orders></orders>
                    </div>
                </div>
            </div>
        </div>
    </div>

</main>