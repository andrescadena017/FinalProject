    <!DOCTYPE html>
    <html lang="es">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="preconnect" href="https://fonts.gstatic.com">

        <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">

        <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">

        <link rel="stylesheet" href="../css/style.css">

        <script src="https://cdn.jsdelivr.net/npm/vue@2/dist/vue.js"></script>
        <title>Toucheat</title>
    </head>

    <body>
        <div id="app">

            <?php
            include("components/$principal_page.php");
            ?>
        </div>
        <script src="../js/components/carrito.js"></script>
        <script src="../js/components/pedidos.js"></script>
        <script src="../js/code.js"></script>
    </body>

    </html>